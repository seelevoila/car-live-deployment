# 汽车直播智能体

面向汽车销售直播场景的本地智能体原型，包含汽车资料知识库、检索问答、GPT-SoVITS 拟人化播报、动态改稿和音色样本管理。

## 快速启动

```powershell
cd C:\Users\seele\Desktop\test
powershell -ExecutionPolicy Bypass -File .\start.ps1
```

打开：http://127.0.0.1:5173

也可以双击 `启动汽车直播智能体.cmd`。如需电脑登录后自动启动一次，执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\install-startup.ps1
```

开机登录任务负责拉起本项目的前端、后端和 GPT-SoVITS；如果 Windows 任务注册失败，会自动退回 Startup 文件夹快捷方式。启动脚本带有防重复锁，不会重复启动已经监听的服务；GPT-SoVITS 仍在加载时，页面会先显示可用并自动等待语音服务恢复。移除开机启动：

```powershell
powershell -ExecutionPolicy Bypass -File .\install-startup.ps1 -Remove
```

服务地址：

- 前端：5173
- 后端 API：8000
- GPT-SoVITS：9880

## 已实现功能

- PDF、DOCX、TXT 多文件批量导入，车型元数据管理；DOCX 段落和表格内容均会进入知识库
- 知识片段切分、离线向量检索、来源和相关度展示
- 资料版本记录、替换、删除和版本查询；删除操作不会移除 `data/sample` 示例源文件
- 直播脚本文本输入和 TXT/MD 文件导入
- GPT-SoVITS PCM WAV 播报：按自然短语使用质量优先的模式 1 生成并以 PCM 流传输到浏览器，避免模式 2/3 的 SOLA 拼接电子点击；低延迟设备可在 `.env` 显式切换为模式 2 或模式 3
- 后端流式接口也会按自然停顿切分长稿，并拼接后续 PCM，直接调用长文本接口同样可以先收到第一段音频
- 按自然停顿短句顺序生成并连续排程，减少句间等待
- 播放中点击“应用动态改稿”不会截断当前正在播放的短语，会在下一个自然停顿安全切换到新稿；未生成的后续内容立即使用新稿
- 语速、音量、语调调节
- GPT-SoVITS v2ProPlus 音色样本上传、参考文本校验与引用音频管理（参考文本为必填，以提升克隆一致性）；新克隆音色使用 v2ProPlus 通用零样本权重，并联合校准声纹相似度与语气稳定性；昔涟按音色记录切换到 GPT-e10 + SoVITS-e6 微调权重，避免不同音色互相污染
- 快速克隆支持样本预检、上传进度、参考文本密度提示和后台预热；参考音频自动压缩异常长内部静音、保留短自然停顿、对高电平样本留出 3 dB 峰值余量，并转为 24kHz 单声道 16-bit PCM WAV，界面展示时长、有效人声比例、静音比例、响度和削波诊断，可一键使用或试听
- 低质量、格式异常或缺少参考文本的克隆音色会标记为“建议优化”且禁止播报，避免影响直播稳定性
- 车型问答文字输出和回答语音播报
- 可选 OpenAI 兼容大模型增强问答；未配置时自动使用本地可复现抽取式 RAG 回退
- 检索准确率、最终问答准确率与 TTS 延迟测试页面
- TTS 单模型推理锁，避免预热、验证、试听和直播并发时触发 GPT-SoVITS 的并发推理限制

## 验收接口

- `POST /api/tests/retrieval`
- `POST /api/tests/qa`
- `POST /api/tests/tts`
- `GET /api/documents/{id}/versions`
- `POST /api/voices/clone`
- `POST /api/voices/analyze`
- `POST /api/voices/{voice_id}/optimize`

详细验收结果见 `docs/ACCEPTANCE.md`。

参赛交付、现场演示、数据合规和主观评测模板见：

- `docs/COMPETITION_SUBMISSION.md`
- `docs/DEMO_RUNBOOK.md`
- `docs/VOICE_EVALUATION.md`

可用 `powershell -ExecutionPolicy Bypass -File .\verify.ps1` 一键复现实验结果。
