const API = 'http://127.0.0.1:8000/api';
const app = document.querySelector('#app');
let session = null;
// Prefer the cloned path while the studio is loading. `play()` refreshes this
// value before starting, so an unavailable GPT-SoVITS service can still fall
// back to browser speech instead of blocking the page.
let ttsMode = 'gpt-sovits';
let audioCtx = null;
let gainNode = null;
let activeSource = null;
let liveRun = null;
let currentAnswer = '';
let serviceOnline = null;
let healthTimer = null;
let healthReloadInFlight = false;

const api = async (path, options = {}) => {
  let response;
  try {
    response = await fetch(API + path, options);
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new Error('无法连接后端服务，请确认项目已启动');
  }
  if (!response.ok) {
    let detail = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      detail = body.detail || detail;
    } catch {
      try { detail += ` ${(await response.text()).slice(0, 200)}`; } catch {}
    }
    throw new Error(detail);
  }
  const type = response.headers.get('content-type') || '';
  return type.includes('application/json') ? response.json() : response;
};

function showViewError(error) {
  const message = error?.message || '页面加载失败';
  app.innerHTML = `<section class="panel"><div class="panel-body"><div class="notice error">${esc(message)}</div><button class="btn" id="retryView">重试</button></div></section>`;
  document.querySelector('#retryView')?.addEventListener('click', () => {
    const active = document.querySelector('nav button.active') || document.querySelector('nav button');
    const view = active?.dataset.view || 'knowledge';
    ({knowledge,studio,tests}[view])().catch(showViewError);
  });
}

function setServiceStatus(online) {
  const node = document.querySelector('#status');
  if (!node) return;
  node.classList.toggle('offline', !online);
  node.textContent = online ? '服务正常' : '服务离线 · 自动重试';
}

async function loadActiveView() {
  if (healthReloadInFlight) return;
  const active = document.querySelector('nav button.active') || document.querySelector('nav button');
  const view = active?.dataset.view || 'knowledge';
  const loader = ({knowledge, studio, tests})[view];
  if (!loader) return;
  healthReloadInFlight = true;
  try { await loader(); } catch (error) { showViewError(error); }
  finally { healthReloadInFlight = false; }
}

async function pollHealth() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1200);
  try {
    await api('/health', {signal: controller.signal});
    const recovered = serviceOnline === false;
    serviceOnline = true;
    setServiceStatus(true);
    // A first load can happen before the backend has finished starting. Once
    // it recovers, replace the error view automatically without a manual click.
    if (recovered && app.querySelector('.notice.error')) await loadActiveView();
  } catch {
    serviceOnline = false;
    setServiceStatus(false);
  } finally {
    clearTimeout(timeout);
  }
}

function startHealthMonitor() {
  if (healthTimer) return;
  pollHealth();
  healthTimer = setInterval(pollHealth, 2500);
}

const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// GPT-SoVITS v2ProPlus mode 1 returns the first clean fragment only after a
// semantic block is ready. Keeping live units at ~20 Chinese characters keeps
// that block below the 3-second target even on the fine-tuned voice profile.
const SPEECH_MAX_CHARS = 20;
const SPEECH_SHORT_CLAUSE_CHARS = 10;
// Keep a short salutation attached to enough phonetic context, but cap the
// merged request so the first live unit still reaches the 3-second target.
// A 48-character opener forced GPT-SoVITS to synthesize too much before its
// first PCM fragment arrived (especially after a model/profile swap).
const SPEECH_CLAUSE_MERGED_MAX = 20;
const sentenceList = text => {
  const raw = text.match(/[^。！？；.!?]+[。！？；.!?]?/g)?.map(x => x.trim()).filter(Boolean) || [];
  if (!raw.length && text.trim()) return [text.trim()];
  // Use natural sentence boundaries first. Long sentences are split into
  // speech-sized phrases, rather than tiny 8-12 character requests that make
  // GPT-SoVITS sound clipped and mechanical.
  const units = [];
  for (const sentence of raw) {
    const clauses = sentence.match(/[^，,、：:]+[，,、：:]?/g)?.map(x => x.trim()).filter(Boolean) || [sentence];
    // A tiny salutation such as “老板，” is a poor standalone cloning prompt.
    // Keep it with the following clause so the first request has enough
    // phonetic context and does not begin with a clipped consonant.
    const pauseClauses = [];
    for (let index = 0; index < clauses.length; index += 1) {
      let combined = clauses[index];
      let relaxed = false;
      const next = clauses[index + 1];
      const shortLead = next && combined.length < SPEECH_SHORT_CLAUSE_CHARS && combined.length + next.length <= SPEECH_CLAUSE_MERGED_MAX;
      const naturalPair = next && combined.length >= 10 && next.length >= 10 && combined.length + next.length <= SPEECH_CLAUSE_MERGED_MAX;
      if (shortLead || naturalPair) {
        combined += next;
        relaxed = true;
        index += 1;
        while (index + 1 < clauses.length && clauses[index + 1].length >= 10 && combined.length + clauses[index + 1].length <= SPEECH_CLAUSE_MERGED_MAX) {
          combined += clauses[index + 1];
          index += 1;
        }
      } else if (next && combined.length < SPEECH_SHORT_CLAUSE_CHARS) {
        // Attach a bounded phonetic context to a short salutation. Sending
        // "老板" alone clips the initial consonant; sending the whole next
        // clause delays the first playable PCM fragment.
        const room = SPEECH_CLAUSE_MERGED_MAX - combined.length - 1; // reserve comma
        const prefixEnd = safeSpeechCut(next, Math.max(1, room));
        const prefix = next.slice(0, prefixEnd).replace(/[，,、：:]$/, '');
        if (prefix) {
          combined += prefix + '，';
          clauses[index + 1] = next.slice(prefixEnd).trim();
          relaxed = true;
        }
      }
      pauseClauses.push({text: combined, relaxed});
    }
    const sentenceUnits = [];
    let current = '';
    for (const clauseInfo of pauseClauses) {
      let clause = clauseInfo.text;
      const clauseLimit = clauseInfo.relaxed ? SPEECH_CLAUSE_MERGED_MAX : 30;
      while (clause.length > clauseLimit) {
        if (current) { sentenceUnits.push(current); current = ''; }
        const cut = safeSpeechCut(clause, SPEECH_MAX_CHARS);
        sentenceUnits.push(clause.slice(0, cut).replace(/[，,、：:]$/, '') + '，');
        clause = clause.slice(cut).trim();
      }
      if (current && current.length + clause.length > 30) {
        sentenceUnits.push(current);
        current = '';
      }
      current += clause;
    }
    if (current) sentenceUnits.push(current);
    // A full stop is an explicit host-facing safety boundary. Never combine two
    // visible sentences, even if either is short: dynamic revisions must be able
    // to replace sentence 2 without disturbing sentence 1.
    units.push(...sentenceUnits);
  }
  return units;
};
const setState = (text, unit = '') => {
  const node = document.querySelector('#playstate');
  if (node) node.textContent = text;
  const detail = document.querySelector('#playunit');
  if (detail) detail.textContent = unit ? `当前短语：${unit}` : '';
};

function renderScriptUnits() {
  const node = document.querySelector('#scriptUnits');
  const script = document.querySelector('#script');
  if (!node || !script) return;
  const units = sentenceList(normalizeSpeechText(script.value));
  node.innerHTML = units.length
    ? `播报切分：${units.map((unit, index) => `<span>${index + 1}. ${esc(unit)}</span>`).join('')}`
    : '播报切分：暂无内容';
}

const CN_DIGITS = ['零','一','二','三','四','五','六','七','八','九'];
const TTS_ATOMIC_TOKEN = /(?:\d+(?:\.\d+)?\s*(?:km\/h|kWh|N·m|km|kW|Nm|公里|毫米|小时|秒|%|L|万元|万|元|年|款|版|型号|EV)?|[零一二三四五六七八九十百千万亿兆点]+(?:公里每小时|千瓦时|牛米|公里|毫米|小时|秒|百分之|升|万元|元|年|款|版|型号|EV)?)/gi;
function safeSpeechCut(text, limit) {
  if (text.length <= limit) return text.length;
  let end = Math.max(1, limit);
  TTS_ATOMIC_TOKEN.lastIndex = 0;
  for (const match of text.matchAll(TTS_ATOMIC_TOKEN)) {
    const start = match.index ?? 0;
    if (start < end && end < start + match[0].length) {
      end = start === 0 ? start + match[0].length : start;
      break;
    }
  }
  return Math.max(1, end);
}
function sectionToChinese(section) {
  if (!section) return '';
  const units = ['','十','百','千'];
  const digits = String(section).split('').map(Number);
  let out = '';
  let pendingZero = false;
  for (let index = 0; index < digits.length; index++) {
    const digit = digits[index];
    const unit = units[digits.length - index - 1];
    if (!digit) {
      if (out) pendingZero = true;
      continue;
    }
    if (pendingZero) { out += '零'; pendingZero = false; }
    out += CN_DIGITS[digit] + unit;
  }
  return out.replace(/^一十/, '十');
}

function numberToChinese(value) {
  const text = String(value);
  if (!/^\d+(?:\.\d+)?$/.test(text)) return text;
  const [intPart, fracPart] = text.split('.');
  const num = parseInt(intPart, 10);
  if (!Number.isFinite(num)) return text;
  if (num === 0) return fracPart ? '零点' + fracPart.split('').map(d => CN_DIGITS[Number(d)]).join('') : '零';
  const sectionUnits = ['', '万', '亿'];
  let n = num;
  const sections = [];
  while (n > 0) { sections.unshift(n % 10000); n = Math.floor(n / 10000); }
  let out = '';
  for (let i = 0; i < sections.length; i++) {
    const sec = sections[i];
    const secText = sectionToChinese(sec);
    if (!secText) {
      if (out && !out.endsWith('零')) out += '零';
      continue;
    }
    out += secText + sectionUnits[sections.length - 1 - i];
    if (i < sections.length - 1 && sections[i + 1] < 1000 && sections[i + 1] > 0) out += '零';
  }
  out = out.replace(/零+/g, '零').replace(/零$/,'');
  if (fracPart) out += '点' + fracPart.split('').map(d => CN_DIGITS[Number(d)]).join('');
  return out;
}

function normalizeSpeechText(input) {
  let text = String(input || '');
  text = text.replace(/^根据当前车型资料[:：]\s*/g, '');
  text = text.replace(/^根据资料[:：]\s*/g, '');
  text = text.replace(/^回答[:：]\s*/g, '');
  // Normalize quantities before sentence splitting so a token such as
  // `580km` remains one speech unit and is read as“五百八十公里”.
  text = text.replace(/(?<!\d)(19\d{2}|20\d{2})(?=\s*(?:年|款|版|型号))/g, match => match.split('').map(d => CN_DIGITS[Number(d)]).join(''));
  const speechUnits = { 'km/h':'公里每小时', 'kWh':'千瓦时', 'N·m':'牛米', km:'公里', kW:'千瓦', Nm:'牛米', '%':'百分之', L:'升', 万元:'万元', 万:'万元', 元:'元', 公里:'公里', 毫米:'毫米', 小时:'小时', 秒:'秒' };
  const speechUnitPattern = 'km/h|kWh|N·m|公里|毫米|小时|秒|km|kW|Nm|%|L|万元|万|元';
  text = text.replace(new RegExp(`(?<![\\d点])(\\d+(?:\\.\\d+)?)[ \\t]*(${speechUnitPattern})?`, 'gi'), (_match, number, unit = '') => numberToChinese(number) + (speechUnits[unit] || unit));
  text = text.replace(/[:：]/g, '，');
  text = text.replace(/\s+/g, ' ').trim();
  text = text.replace(/，+/g, '，').replace(/。+/g, '。');
  return text;
}

function layout(title, desc, body) {
  app.innerHTML = `<section class="heading"><div><p class="eyebrow">Car Live Agent</p><h1>${title}</h1><p>${desc}</p></div></section>${body}`;
}

async function knowledge() {
  const [docs, dash] = await Promise.all([api('/documents'), api('/dashboard')]);
  layout('汽车资料知识库', '批量管理车型资料、版本和可溯源检索内容。', `
    <div class="metrics"><div class="metric"><b>${dash.documents}</b><span>资料文件</span></div><div class="metric"><b>${dash.chunks}</b><span>知识片段</span></div><div class="metric"><b>${dash.versions}</b><span>资料版本</span></div><div class="metric"><b>${dash.vehicles.length}</b><span>车型版本</span></div></div>
    <section class="panel"><div class="panel-head"><h2>批量导入资料</h2><span>PDF / Word / TXT</span></div><div class="panel-body upload"><label class="drop">选择多个汽车资料文件<input id="files" type="file" accept=".pdf,.docx,.txt" multiple hidden></label><div class="fields"><label>品牌<input id="brand" placeholder="欧拉"></label><label>车系<input id="series" placeholder="欧拉5 EV"></label><label>年款<input id="year" placeholder="2026"></label><button class="btn" id="upload">批量上传并入库</button></div></div></section>
    <section class="panel"><div class="panel-head"><h2>资料清单</h2><span id="uploadState"></span></div><div class="panel-body"><table class="table"><tr><th>文件</th><th>车型</th><th>片段</th><th>版本</th><th>操作</th></tr>${docs.map(x => `<tr><td>${esc(x.name)}</td><td>${esc(x.brand)} / ${esc(x.series)} / ${esc(x.year)}</td><td>${x.chunks}</td><td>v${x.version || 1}</td><td><button class="btn secondary versions" data-id="${x.id}">版本</button> <button class="btn secondary replace-trigger" data-id="${x.id}">替换</button> <button class="btn secondary del" data-id="${x.id}">删除</button><input class="replace" data-id="${x.id}" data-brand="${esc(x.brand)}" data-series="${esc(x.series)}" data-year="${esc(x.year)}" type="file" accept=".pdf,.docx,.txt" hidden></td></tr>`).join('')}</table></div></section>`);
  document.querySelector('#upload').onclick = uploadBatch;
  document.querySelectorAll('.del').forEach(button => button.onclick = async () => { if (confirm('确定删除这份资料及其版本吗？')) { await api('/documents/' + button.dataset.id, {method:'DELETE'}); knowledge(); } });
  document.querySelectorAll('.replace-trigger').forEach(button => button.onclick = () => document.querySelector(`.replace[data-id="${button.dataset.id}"]`)?.click());
  document.querySelectorAll('.replace').forEach(input => input.onchange = async () => { if (input.files[0]) await replaceDocument(input); });
  document.querySelectorAll('.versions').forEach(button => button.onclick = async () => { const rows = await api('/documents/' + button.dataset.id + '/versions'); alert(rows.map(x => `v${x.version} · ${x.name} · ${x.chunks}片段`).join('\n') || '暂无版本记录'); });
}

async function uploadBatch() {
  const files = document.querySelector('#files').files;
  if (!files.length) return alert('请先选择一个或多个文件');
  const form = new FormData();
  [...files].forEach(file => form.append('files', file));
  ['brand','series','year'].forEach(key => form.append(key, document.querySelector('#' + key).value));
  document.querySelector('#uploadState').textContent = '导入中…';
  try { const result = await api('/documents/batch', {method:'POST', body:form}); document.querySelector('#uploadState').textContent = `已导入 ${result.count} 个文件`; knowledge().catch(showViewError); } catch (error) { document.querySelector('#uploadState').textContent = error.message; }
}

async function replaceDocument(input) {
  const file = input.files[0];
  const form = new FormData();
  form.append('file', file);
  form.append('brand', input.dataset.brand || '');
  form.append('series', input.dataset.series || '');
  form.append('year', input.dataset.year || '');
  const state = document.querySelector('#uploadState');
  if (state) state.textContent = `正在替换 ${file.name}…`;
  try {
    const result = await api('/documents/' + input.dataset.id, {method:'PUT', body:form});
    if (state) state.textContent = `已更新为新版本（${result.status}）`;
    await knowledge();
  } catch (error) {
    if (state) state.textContent = error.message;
  } finally {
    input.value = '';
  }
}

function vehicleOptions(vehicles) {
  return vehicles.map(v => `<option value="${esc([v.brand,v.series,v.year].join(' / '))}" data-brand="${esc(v.brand)}" data-series="${esc(v.series)}" data-year="${esc(v.year)}">${esc([v.brand,v.series,v.year].join(' / '))}</option>`).join('');
}

function selectedVoiceIsClone() {
  return document.querySelector('#voice')?.selectedOptions[0]?.dataset.cloned === '1';
}

async function studio() {
  const [dash, voices, tts] = await Promise.all([api('/dashboard'), api('/voices'), api('/tts/status')]);
  ttsMode = tts.provider;
  const first = dash.vehicles[0] || {brand:'欧拉',series:'欧拉5 EV',year:'2026'};
  layout('汽车直播控制台', '知识库问答、脚本生成、动态改稿和拟人化语音播报。', `
    <section class="panel"><div class="panel-body fields studio-settings"><label>绑定车型<select id="vehicle">${vehicleOptions(dash.vehicles)}</select></label><label>主播音色<select id="voice">${voices.map(v => { const quality = v.quality?.status === 'ready' ? ' · PCM 已优化' : v.quality?.status === 'invalid' ? ' · 音频格式异常' : v.quality?.status === 'needs-review' ? ' · 建议优化' : ''; const disabled = v.cloned && v.quality?.status !== 'ready' ? ' disabled' : ''; const label = v.cloned ? ' · 已克隆' : v.profile && Object.keys(v.profile).length ? ' · GPT-SoVITS 预置风格' : ' · 预置音色'; return `<option value="${esc(v.id)}" data-cloned="${v.cloned ? '1' : '0'}"${disabled}>${esc(v.name)} · ${esc(v.style)}${label}${quality}</option>`; }).join('')}</select></label><label>语速 <output id="speedOut">1.00</output><input id="speed" type="range" min="0.7" max="1.4" value="1.00" step="0.01"></label><label>音量 <output id="volumeOut">100%</output><input id="volume" type="range" min="0" max="1" value="1" step="0.05"></label><label>语调 <output id="pitchOut">0</output><input id="pitch" type="range" min="-4" max="4" value="0" step="1"></label><span id="ttsMode">检查语音引擎…</span></div></section>
    <section class="panel"><div class="panel-head"><h2>音色试听与调整</h2><span>自然表达 · 先试听当前选中的音色</span></div><div class="panel-body"><textarea id="voicePreviewText" class="question">大家好，欢迎来到汽车直播间，今天给大家介绍这款车型。</textarea><div class="fields preview-settings"><label class="check"><input id="autoProsody" type="checkbox" checked> 自动匹配音色与语气</label><label>表达度 <output id="temperatureOut">0.75</output><input id="temperature" type="range" min="0.45" max="1.2" value="0.75" step="0.01"></label><label>稳定性 <output id="repetitionOut">1.30</output><input id="repetition" type="range" min="1.0" max="1.6" value="1.30" step="0.01"></label></div><div class="controls"><button class="btn" id="previewVoice">试听当前音色</button><button class="btn secondary" id="stopPreview">停止试听</button></div><p class="hint">默认按每个克隆音色的声纹和音高稳定性自动选择参数；关闭“自动匹配”后才使用手动滑块。</p></div></section>
    <div class="studio"><section class="panel"><div class="panel-head"><h2>直播稿</h2><span id="version"></span></div><div class="panel-body"><div class="inline-tools"><label class="btn secondary file-btn">导入脚本文件<input id="scriptFile" type="file" accept=".txt,.md" hidden></label><button class="btn secondary" id="generate">按卖点生成脚本</button></div><textarea id="script">老板，今天为大家介绍欧拉 5 EV 2026 款 580km 激光雷达版。它的 CLTC 纯电续航为 580 公里，轴距 2720 毫米，最大功率 150 千瓦。</textarea><p id="scriptUnits" class="script-units"></p><div class="controls"><button class="btn" id="play">开始播放</button><button class="btn secondary" id="pause">暂停</button><button class="btn secondary" id="stop">停止</button><button class="btn secondary" id="revise">应用动态改稿</button></div><p id="playstate">当前句 0 / 0 · 待机</p><p id="playunit" class="hint"></p><p class="hint">GPT-SoVITS 模式下，音频以自然停顿短语实时生成并播放；改稿不会截断当前短语，会在下一个自然停顿安全切换后续新稿。</p></div></section>
    <aside class="panel"><div class="panel-head"><h2>观众问答</h2></div><div class="panel-body"><textarea class="question" id="question">欧拉 5 EV 的续航是多少？</textarea><button class="btn" id="ask">发送并检索</button><button class="btn secondary" id="speakAnswer">语音播报回答</button><div id="answer"></div></div></aside></div>
    <section class="panel"><div class="panel-head"><h2>快速克隆音色</h2><span>上传少量真人样本，检查后立即接入流式播报</span></div><div class="panel-body clone-grid"><label>音色名称<input id="voiceName" value="我的主播"></label><label>风格<input id="voiceStyle" value="亲民"></label><label>主参考音频<input id="voiceFile" type="file" accept=".wav,.mp3,.flac,.ogg,.m4a"><small id="voiceFileMeta" class="hint">3-10 秒，主参考音频必须填写对应原文</small></label><label>辅助参考音频（可选）<input id="voiceAuxFiles" type="file" multiple accept=".wav,.mp3,.flac,.ogg,.m4a"><small id="voiceAuxMeta" class="hint">最多 2 条；同一说话人的不同句子，不需要填写文字</small></label><label>参考文本（必填）<input id="voicePrompt" maxlength="500" placeholder="填写主参考音频中实际说出的原文，须逐字一致"><small id="voicePromptMeta" class="hint">至少 4 个字；标点和停顿也尽量保持一致</small></label><div class="clone-actions"><button class="btn secondary" id="analyzeVoice">检查样本</button><button class="btn" id="clone">上传并创建音色</button><progress id="voiceProgress" max="100" value="0" hidden></progress><span id="cloneState"></span></div><div class="voice-list"><h3>已保存音色</h3>${voices.map(v => { const quality = v.quality?.message || ''; const qualityLabel = v.quality?.status === 'ready' ? ' · PCM 已优化' : v.quality?.status === 'invalid' ? ' · 音频格式异常' : v.quality?.status === 'needs-review' ? ' · 建议优化' : ''; const warmLabel = v.calibrating ? ' · 音色校准中' : v.warming ? ' · 预热中' : v.warmed ? ' · 可立即播报' : ''; const referenceLabel = v.reference_count > 1 ? ` · ${v.reference_count} 条参考` : ''; const advice = v.prompt_advice?.status === 'review' ? ` · ${v.prompt_advice.message}` : ''; const prosody = v.prosody_advice ? ` · ${v.prosody_advice}` : ''; const actionDisabled = v.quality?.status !== 'ready' || v.warming ? ' disabled' : ''; return `<div class="voice-row"><div><span>${esc(v.name)} · ${esc(v.style)}${v.cloned ? ' · 已克隆' : ' · 预置音色'}${referenceLabel}${qualityLabel}${warmLabel}</span>${v.cloned ? `<small class="hint">${esc(quality)}${esc(advice)}${esc(prosody)}</small><div class="voice-row-actions"><button class="btn secondary voice-use" data-id="${esc(v.id)}"${actionDisabled}>使用</button><button class="btn secondary voice-preview" data-id="${esc(v.id)}"${actionDisabled}>试听</button><input class="voice-prompt" data-id="${esc(v.id)}" value="${esc(v.prompt_text || '')}" placeholder="主参考音频原文（必须与录音一致）"><button class="btn secondary voice-save" data-id="${esc(v.id)}">保存参考文本</button></div>` : ''}</div>${v.cloned ? `<button class="btn secondary voice-delete" data-id="${esc(v.id)}">删除</button>` : ''}</div>`; }).join('')}</div><p class="hint">新克隆使用 GPT-SoVITS v2ProPlus 通用零样本权重；系统会同时比较声纹相似度、异常升调和音高跳变，不针对任何单一角色调参。修改参考文本或重新优化音频后会自动重新预热和校准。</p></div></section>`);
  document.querySelector('#play').onclick = play;
  document.querySelector('#pause').onclick = pause;
  document.querySelector('#stop').onclick = stop;
  document.querySelector('#revise').onclick = revise;
  document.querySelector('#ask').onclick = ask;
  document.querySelector('#speakAnswer').onclick = () => currentAnswer && speakText(currentAnswer);
  document.querySelector('#scriptFile').onchange = readScriptFile;
  document.querySelector('#script').oninput = renderScriptUnits;
  document.querySelector('#generate').onclick = generateScript;
  document.querySelector('#clone').onclick = cloneVoice;
  document.querySelector('#analyzeVoice').onclick = analyzeVoiceSample;
  document.querySelector('#voiceFile').onchange = inspectVoiceFile;
  document.querySelector('#voiceAuxFiles').onchange = inspectAuxFiles;
  document.querySelector('#voicePrompt').oninput = updatePromptMeta;
  document.querySelector('#previewVoice').onclick = () => previewVoice();
  document.querySelector('#stopPreview').onclick = () => { stopGpt(); speechSynthesis.cancel(); setState('已停止试听'); };
  const applySamplingProfile = () => {
    const selected = voices.find(item => item.id === document.querySelector('#voice')?.value);
    const sampling = selected?.sampling_profile || {temperature:0.75, repetition_penalty:1.3};
    const auto = document.querySelector('#autoProsody');
    const temperature = document.querySelector('#temperature');
    const repetition = document.querySelector('#repetition');
    if (auto?.checked) {
      if (temperature) temperature.value = sampling.temperature ?? 0.75;
      if (repetition) repetition.value = sampling.repetition_penalty ?? 1.3;
    }
    if (temperature) temperature.disabled = Boolean(auto?.checked);
    if (repetition) repetition.disabled = Boolean(auto?.checked);
    updateOutputs();
  };
  document.querySelector('#voice').onchange = applySamplingProfile;
  document.querySelector('#autoProsody').onchange = applySamplingProfile;
  document.querySelectorAll('.voice-delete').forEach(button => button.onclick = async () => {
    if (!confirm('确定删除这个克隆音色吗？')) return;
    await api('/voices/' + button.dataset.id, {method:'DELETE'});
    studio();
  });
  document.querySelectorAll('.voice-use').forEach(button => button.onclick = () => {
    const select = document.querySelector('#voice');
    if (select) select.value = button.dataset.id;
    applySamplingProfile();
    setState('已切换到选中的克隆音色');
  });
  document.querySelectorAll('.voice-preview').forEach(button => button.onclick = async () => {
    const select = document.querySelector('#voice');
    if (select) select.value = button.dataset.id;
    applySamplingProfile();
    const voice = voices.find(item => item.id === button.dataset.id);
    if (voice?.warming) return setState(voice.calibrating ? '该音色正在自动校准音色，请稍候再试听' : '该音色正在预热，请稍候再试听');
    await previewVoice();
  });
  document.querySelectorAll('.voice-save').forEach(button => button.onclick = async () => {
    const input = document.querySelector(`.voice-prompt[data-id="${button.dataset.id}"]`);
    button.disabled = true;
    try {
      const result = await api('/voices/' + button.dataset.id, {method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({prompt_text: input.value.trim()})});
      if (result.warming) {
        button.textContent = '校准中…';
        await waitForVoiceWarmup(button.dataset.id);
        await studio();
      } else {
        button.textContent = '已保存';
        setTimeout(() => { button.textContent = '保存参考文本'; button.disabled = false; }, 1200);
      }
    } catch (error) { button.disabled = false; alert(error.message); }
  });
  document.querySelectorAll('.voice-save').forEach(button => {
    const optimize = document.createElement('button');
    optimize.className = 'btn secondary voice-optimize';
    optimize.textContent = '优化参考音频';
    optimize.dataset.id = button.dataset.id;
    optimize.onclick = async () => {
      optimize.disabled = true;
      optimize.textContent = '处理中…';
      try { await api('/voices/' + optimize.dataset.id + '/optimize', {method:'POST'}); await studio(); }
      catch (error) { optimize.disabled = false; optimize.textContent = '优化失败'; alert(error.message); }
    };
    button.parentElement.appendChild(optimize);
  });
  ['speed','volume','pitch','temperature','repetition'].forEach(id => document.querySelector('#' + id).oninput = () => updateOutputs());
  updateOutputs();
  renderScriptUnits();
  updatePromptMeta();
  inspectVoiceFile();
  inspectAuxFiles();
  const modeNode = document.querySelector('#ttsMode');
  if (modeNode) modeNode.textContent = ttsMode === 'gpt-sovits' ? 'GPT-SoVITS · PCM 实时流式播报' : 'Web Speech API（回退模式）';
  // Prefer the uploaded cloned voice instead of silently starting with a preset.
  // Do not auto-select a legacy clone without its transcript: GPT-SoVITS can
  // still use it, but the result would be less stable and the server correctly
  // asks the host to complete the reference text first.
  const clonedVoice = voices.find(v => v.cloned && v.prompt_text?.trim() && v.quality?.status === 'ready');
  if (clonedVoice) document.querySelector('#voice').value = clonedVoice.id;
  applySamplingProfile();
  // Keep the first option selected even when the browser preserves a previous form state.
  if (dash.vehicles.length) document.querySelector('#vehicle').value = [first.brand,first.series,first.year].join(' / ');
}

function updateOutputs() {
  const speed = document.querySelector('#speed'); const volume = document.querySelector('#volume'); const pitch = document.querySelector('#pitch'); const temperature = document.querySelector('#temperature'); const repetition = document.querySelector('#repetition');
  if (!speed) return;
  document.querySelector('#speedOut').textContent = Number(speed.value).toFixed(2);
  document.querySelector('#volumeOut').textContent = Math.round(Number(volume.value) * 100) + '%';
  document.querySelector('#pitchOut').textContent = (Number(pitch.value) > 0 ? '+' : '') + pitch.value;
  if (temperature) document.querySelector('#temperatureOut').textContent = Number(temperature.value).toFixed(2);
  if (repetition) document.querySelector('#repetitionOut').textContent = Number(repetition.value).toFixed(2);
}

async function ensure() {
  if (session) return session;
  session = await api('/live/sessions', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({vehicle:document.querySelector('#vehicle').value, script:document.querySelector('#script').value, voice_id:document.querySelector('#voice').value})});
  return session;
}

// GPT-SoVITS mode 1 returns one quality-first fragment per natural unit. Keep
// that unit in one AudioBuffer so the browser never creates clicks at arbitrary
// PCM network-chunk boundaries. The next unit is still generated while this
// one is playing, so the full script is never buffered before playback starts.
const STREAM_LEAD_SECONDS = 0.08;
const STREAM_BOUNDARY_FADE_FRAMES = 64;

function stopSource() { if (activeSource) { try { activeSource.stop(); } catch {} activeSource = null; } }

function stopSources(run) {
  run?.sources?.forEach(source => { try { source.stop(); } catch {} });
  if (run?.sources) run.sources.clear();
  stopSource();
}

function stopLive({suspend = false} = {}) {
  const run = liveRun;
  if (run) {
    run.stopped = true;
    run.abortController?.abort();
    run.resumeWaiter?.();
    if (run.mode === 'browser') speechSynthesis.cancel();
    stopSources(run);
    if (liveRun === run) liveRun = null;
  }
  if (suspend && audioCtx?.state === 'running') audioCtx.suspend();
}

function stopGpt() { stopLive({suspend:true}); }

async function ensureAudio() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) throw new Error('浏览器不支持 Web Audio');
  audioCtx = audioCtx || new AudioContextClass();
  gainNode = gainNode || audioCtx.createGain();
  if (!gainNode.__liveConnected) { gainNode.connect(audioCtx.destination); gainNode.__liveConnected = true; }
  if (audioCtx.state !== 'running') await audioCtx.resume();
  if (audioCtx.state !== 'running') throw new Error('浏览器音频输出被挂起，请点击页面后重试');
}

function saveLiveState(status, sentence) {
  if (!session) return;
  api('/live/sessions/' + session.id + '/state', {method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({status, sentence})}).catch(() => {});
}

function createLiveRun(mode, q, startIndex = 0) {
  return {
    mode, q, nextIndex:startIndex, currentIndex:startIndex, stopped:false, paused:false,
    failed:false,
    inFlight:0, abortController:null, resumeWaiter:null, sources:new Set(),
    headerBytes:new Uint8Array(), pcm:new Uint8Array(), format:null, scheduledUntil:0,
    hasScheduledAudio:false, lastScheduledSource:null,
    revision:0, pendingRestartAt:null,
  };
}

function sharedPrefixLength(before, after) {
  let index = 0;
  while (index < before.length && index < after.length && before[index] === after[index]) index += 1;
  return index;
}

function finishRunIfDrained(run) {
  if (run.stopped || run.failed || liveRun !== run || run.inFlight || run.pendingRestartAt !== null || run.sources.size || run.nextIndex < run.q.length) return;
  setState(`流式播报完成 · 共 ${run.q.length} 句`);
  saveLiveState('completed', run.q.length);
  liveRun = null;
}

function appendBytes(left, right) {
  if (!left.length) return new Uint8Array(right);
  const merged = new Uint8Array(left.length + right.length);
  merged.set(left); merged.set(right, left.length);
  return merged;
}

function readFourCC(bytes, offset) {
  return String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
}

function parseWavHeader(bytes) {
  if (bytes.length < 12) return null;
  if (readFourCC(bytes, 0) !== 'RIFF' || readFourCC(bytes, 8) !== 'WAVE') throw new Error('流式接口未返回 PCM WAV 音频');
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = 12;
  let format = null;
  while (offset + 8 <= bytes.length) {
    const name = readFourCC(bytes, offset);
    const size = view.getUint32(offset + 4, true);
    const body = offset + 8;
    if (body + size > bytes.length) return null;
    if (name === 'fmt ') {
      if (size < 16) throw new Error('WAV 音频格式无效');
      format = {
        audioFormat:view.getUint16(body, true), channels:view.getUint16(body + 2, true),
        sampleRate:view.getUint32(body + 4, true), bitsPerSample:view.getUint16(body + 14, true),
      };
    }
    if (name === 'data') return format ? {...format, dataOffset:body} : null;
    offset = body + size + (size % 2);
  }
  return null;
}

function fadeBufferEdge(buffer, fadeIn = false, fadeOut = false) {
  const frames = Math.min(STREAM_BOUNDARY_FADE_FRAMES, buffer.length);
  if (!frames) return;
  for (let channel = 0; channel < buffer.numberOfChannels; channel += 1) {
    const samples = buffer.getChannelData(channel);
    for (let frame = 0; frame < frames; frame += 1) {
      if (fadeIn) samples[frame] *= frame / frames;
      if (fadeOut) {
        const index = samples.length - frames + frame;
        samples[index] *= (frames - frame - 1) / frames;
      }
    }
  }
}

function schedulePcm(run, bytes, unitIndex) {
  const {audioFormat, channels, sampleRate, bitsPerSample} = run.format;
  if (audioFormat !== 1 || bitsPerSample !== 16 || !channels || !sampleRate) throw new Error('目前仅支持 16-bit PCM WAV 流');
  const bytesPerFrame = channels * 2;
  run.pcm = appendBytes(run.pcm, bytes);
  const scheduleAvailable = flush => {
    // Accumulate each natural unit until its upstream response closes. Mode 1
    // already emits quality-first fragments, so slicing them mid-fragment only
    // adds Web Audio node boundaries and audible ticks.
    if (!flush) return;
    while (wholeFramesForQueue(run, bytesPerFrame) > 0) {
      const frames = wholeFramesForQueue(run, bytesPerFrame);
      const consume = frames * bytesPerFrame;
      const view = new DataView(run.pcm.buffer, run.pcm.byteOffset, consume);
      const buffer = audioCtx.createBuffer(channels, frames, sampleRate);
      for (let channel = 0; channel < channels; channel += 1) {
        const samples = buffer.getChannelData(channel);
        for (let frame = 0; frame < frames; frame += 1) samples[frame] = view.getInt16((frame * channels + channel) * 2, true) / 32768;
      }
      run.pcm = run.pcm.slice(consume);
      const source = audioCtx.createBufferSource();
      source.buffer = buffer;
      source.liveIndex = unitIndex;
      // A Web Audio source boundary can click even when the PCM samples are
      // adjacent, because the browser may start the next node a fraction late.
      // Fade every scheduled boundary over 2ms, not only phrase boundaries.
      if (run.lastScheduledSource?.buffer && run.sources.has(run.lastScheduledSource)) {
        fadeBufferEdge(run.lastScheduledSource.buffer, false, true);
      }
      if (run.hasScheduledAudio) {
        fadeBufferEdge(buffer, true, false);
      }
      source.playbackRate.value = Math.pow(2, Number(document.querySelector('#pitch')?.value || 0) / 12);
      source.connect(gainNode);
      gainNode.gain.value = Number(document.querySelector('#volume')?.value || 1);
      const when = Math.max(audioCtx.currentTime + STREAM_LEAD_SECONDS, run.scheduledUntil);
      run.scheduledUntil = when + buffer.duration / Math.max(0.01, source.playbackRate.value);
      source.liveStart = when;
      source.liveEnd = run.scheduledUntil;
      run.sources.add(source); activeSource = source;
      run.hasScheduledAudio = true;
      run.lastScheduledSource = source;
      source.onended = () => { run.sources.delete(source); if (activeSource === source) activeSource = null; finishRunIfDrained(run); };
      source.start(when);
    }
  };
  scheduleAvailable(false);
  return () => scheduleAvailable(true);
}

function wholeFramesForQueue(run, bytesPerFrame) {
  return Math.floor(run.pcm.length / bytesPerFrame);
}

function consumeStreamBytes(run, bytes, unitIndex) {
  if (!run.format) {
    run.headerBytes = appendBytes(run.headerBytes, bytes);
    const format = parseWavHeader(run.headerBytes);
    if (!format) return null;
    run.format = format;
    const audioBytes = run.headerBytes.slice(format.dataOffset);
    run.headerBytes = new Uint8Array();
    return schedulePcm(run, audioBytes, unitIndex);
  }
  return schedulePcm(run, bytes, unitIndex);
}

function safePlaybackIndex(run) {
  const now = audioCtx?.currentTime || 0;
  const indices = [...run.sources]
    .filter(source => source.liveEnd > now + 0.01)
    .map(source => source.liveIndex);
  return indices.length ? Math.min(...indices) : Math.max(0, run.currentIndex);
}

function discardUnplayedSources(run, fromIndex) {
  const now = audioCtx?.currentTime || 0;
  for (const source of [...run.sources]) {
    if (source.liveIndex >= fromIndex && source.liveStart > now + 0.02) {
      try { source.stop(); } catch {}
      run.sources.delete(source);
    }
  }
  run.scheduledUntil = Math.max(
    now + STREAM_LEAD_SECONDS,
    ...[...run.sources].map(source => source.liveEnd || 0),
  );
}

function waitWhilePaused(run) {
  if (!run.paused) return Promise.resolve();
  return new Promise(resolve => { run.resumeWaiter = resolve; });
}

async function streamGptUnit(run) {
  if (run.stopped || liveRun !== run || run.paused) return;
  if (run.nextIndex >= run.q.length) { finishRunIfDrained(run); return; }
  const index = run.nextIndex++;
  const revision = run.revision;
  run.currentIndex = index;
  run.inFlight += 1;
  run.headerBytes = new Uint8Array(); run.pcm = new Uint8Array(); run.format = null;
  const controller = new AbortController();
  run.abortController = controller;
  setState(`GPT-SoVITS 流式生成 · 第 ${index + 1} / ${run.q.length} 句`, run.q[index]);
  saveLiveState('generating', index);
  try {
    const response = await fetch(API + '/tts/stream', {method:'POST', headers:{'Content-Type':'application/json'}, body:ttsBody(run.q[index], true), signal:controller.signal});
    if (!response.ok) throw new Error(`TTS HTTP ${response.status} ${(await response.text()).slice(0, 120)}`);
    if (!response.body) throw new Error('浏览器不支持可读音频流');
    const reader = response.body.getReader();
    let flush = null; let playbackStarted = false;
    while (true) {
      await waitWhilePaused(run);
      if (run.stopped || liveRun !== run) { try { await reader.cancel(); } catch {} return; }
      if (revision !== run.revision) { try { await reader.cancel(); } catch {} break; }
      const {done, value} = await reader.read();
      if (done) break;
      if (revision !== run.revision) { try { await reader.cancel(); } catch {} break; }
      flush = consumeStreamBytes(run, value, index);
      if (!playbackStarted && run.sources.size) {
        playbackStarted = true;
        setState(`GPT-SoVITS 流式播放 · 第 ${index + 1} / ${run.q.length} 句`, run.q[index]);
        saveLiveState('playing', index);
      }
    }
    // A revision or stop can cancel a request after its last chunk arrived.
    // Never flush that stale PCM into the scheduler after the safe-cut check.
    if (revision === run.revision && !run.stopped && liveRun === run) flush?.();
    if (!playbackStarted && run.sources.size) {
      setState(`GPT-SoVITS 流式播放 · 第 ${index + 1} / ${run.q.length} 句`, run.q[index]);
      saveLiveState('playing', index);
    }
    if (!playbackStarted && !run.sources.size) throw new Error('TTS 未返回可播放音频');
  } catch (error) {
    if (!run.stopped && error.name !== 'AbortError') {
      run.failed = true;
      run.nextIndex = run.q.length;
      run.pendingRestartAt = null;
      console.error(error);
      setState('GPT-SoVITS 流式请求失败：' + error.message);
    }
  } finally {
    run.inFlight -= 1;
    if (run.abortController === controller) run.abortController = null;
  }
  if (revision !== run.revision) {
    if (!run.stopped && liveRun === run && !run.paused && run.pendingRestartAt !== null) {
      run.pendingRestartAt = null;
      void streamGptUnit(run);
    }
    return;
  }
  if (run.stopped || run.failed || liveRun !== run || run.paused) return;
  // Start requesting the next sentence as soon as this sentence has finished
  // generating. Its PCM is scheduled after the buffered audio, avoiding a
  // sentence-to-sentence gap without generating the entire script first.
  if (run.nextIndex < run.q.length) void streamGptUnit(run);
  else finishRunIfDrained(run);
}

async function startGptRun(q, startIndex = 0) {
  stopLive();
  const run = createLiveRun('gpt-sovits', q, startIndex);
  liveRun = run;
  try { await ensureAudio(); } catch (error) { liveRun = null; setState('浏览器不支持音频播放：' + error.message); return; }
  if (!run.stopped) void streamGptUnit(run);
}

function speakBrowserUnit(run) {
  if (run.stopped || liveRun !== run || run.paused) return;
  if (run.nextIndex >= run.q.length) { finishRunIfDrained(run); return; }
  const index = run.nextIndex++;
  run.currentIndex = index;
  const utterance = new SpeechSynthesisUtterance(run.q[index]);
  utterance.lang = 'zh-CN'; utterance.rate = Number(document.querySelector('#speed')?.value || 1); utterance.volume = Number(document.querySelector('#volume')?.value || 1);
  utterance.onstart = () => { setState(`浏览器语音播报 · 第 ${index + 1} / ${run.q.length} 句`, run.q[index]); saveLiveState('playing', index); };
  utterance.onend = () => { if (!run.stopped) speakBrowserUnit(run); };
  utterance.onerror = event => { if (!run.stopped && event.error !== 'canceled') setState('浏览器语音播放失败：' + event.error); };
  speechSynthesis.speak(utterance);
}

function startBrowserRun(q, startIndex = 0) {
  stopLive(); speechSynthesis.cancel();
  const run = createLiveRun('browser', q, startIndex);
  liveRun = run; speakBrowserUnit(run);
}

async function resumeLive(run) {
  run.paused = false;
  if (run.mode === 'browser') { speechSynthesis.resume(); setState('浏览器语音继续播报'); return; }
  try { await ensureAudio(); } catch (error) { setState('无法恢复音频：' + error.message); return; }
  const resume = run.resumeWaiter; run.resumeWaiter = null; resume?.();
  if (!run.inFlight) void streamGptUnit(run);
  setState('GPT-SoVITS 流式播报已继续');
}

async function syncTtsMode() {
  try {
    const status = await api('/tts/status');
    ttsMode = status.provider;
  } catch {
    ttsMode = 'browser';
  }
  const modeNode = document.querySelector('#ttsMode');
  if (modeNode) modeNode.textContent = ttsMode === 'gpt-sovits' ? 'GPT-SoVITS · PCM 实时流式播报' : 'Web Speech API（回退模式）';
  return ttsMode;
}

async function play() {
  // Resume/create Web Audio before the first network await. Browsers associate
  // autoplay permission with the original click task; waiting for session
  // creation first can leave the context suspended while TTS still succeeds.
  let audioReady = false;
  try { await ensureAudio(); audioReady = true; } catch {}
  await syncTtsMode();
  if (ttsMode === 'gpt-sovits' && !audioReady) {
    try { await ensureAudio(); } catch (error) { setState('无法启动音频输出：' + error.message); return; }
  }
  try { await ensure(); } catch (error) { setState('无法创建直播会话：' + error.message); return; }
  if (liveRun?.paused) { await resumeLive(liveRun); return; }
  const q = sentenceList(normalizeSpeechText(document.querySelector('#script').value));
  if (!q.length) return setState('请先填写直播稿');
  if (ttsMode === 'gpt-sovits') await startGptRun(q); else startBrowserRun(q);
}

function pause() {
  if (!liveRun) return speechSynthesis.pause();
  liveRun.paused = true;
  if (liveRun.mode === 'browser') speechSynthesis.pause(); else if (audioCtx?.state === 'running') audioCtx.suspend();
  setState('已暂停；修改稿件后可继续播放新内容');
}

function stop() { stopLive({suspend:true}); speechSynthesis.cancel(); setState('已停止'); }

async function revise() {
  const nextQueue = sentenceList(normalizeSpeechText(document.querySelector('#script').value));
  if (!nextQueue.length) return setState('改稿内容不能为空');
  const saved = await ensure();
  const run = liveRun;
  const beforeQueue = run ? run.q.slice() : [];
  const changedAt = run ? sharedPrefixLength(run.q, nextQueue) : 0;
  const safeIndex = run ? safePlaybackIndex(run) : 0;
  session = await api('/live/sessions/' + saved.id + '/script', {method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({script:document.querySelector('#script').value, sentence:changedAt})});
  document.querySelector('#version').textContent = '会话版本 v' + session.version;
  if (!run || run.stopped) { setState('稿件已同步；点击“开始播放”后使用新稿'); return; }
  // Never cancel the phrase that is currently audible. The old implementation
  // called stopLive() here, which clipped the current sentence and made even a
  // distant edit feel like a restart. We keep the active phrase and replace
  // only the tail at its next natural pause.
  run.q = nextQueue;
  const applyFrom = Math.max(changedAt, safeIndex + 1);
  const scriptChanged = changedAt < beforeQueue.length || nextQueue.length !== beforeQueue.length;
  if (changedAt <= safeIndex) {
    // This exact short phrase has already entered the audio device and cannot
    // be changed without an audible cut or replay. Preserve it and apply every
    // later phrase from the next natural pause.
    if (nextQueue.length <= applyFrom) {
      run.nextIndex = nextQueue.length;
      if (run.mode === 'gpt-sovits' && run.inFlight && run.currentIndex >= applyFrom) {
        run.revision += 1;
        run.pendingRestartAt = null;
        discardUnplayedSources(run, applyFrom);
        run.abortController?.abort();
      }
      setState('稿件已更新；当前短语不打断，结束后停止播报');
      return;
    }
  }
  if (run.mode === 'gpt-sovits' && scriptChanged) {
    // Invalidate generated-but-not-audible tail audio. If the active request
    // is still before the edit point, let it finish and continue through any
    // unchanged phrases before requesting the replacement tail.
    const abortFuture = run.inFlight && run.currentIndex >= applyFrom;
    const hasQueuedTail = [...run.sources].some(source => source.liveIndex >= applyFrom && source.liveStart > (audioCtx?.currentTime || 0) + 0.02);
    const hadStaleIndex = run.nextIndex > applyFrom;
    if (abortFuture || hasQueuedTail || hadStaleIndex || run.nextIndex < nextQueue.length) {
      if (abortFuture) run.revision += 1;
      run.nextIndex = Math.min(run.nextIndex, applyFrom);
      run.pendingRestartAt = abortFuture ? applyFrom : null;
      discardUnplayedSources(run, applyFrom);
      if (abortFuture) run.abortController?.abort();
      if (!abortFuture && !run.paused && run.nextIndex < run.q.length && !run.inFlight) void streamGptUnit(run);
      setState(`稿件已更新；当前第 ${safeIndex + 1} 段继续播放，新第 ${applyFrom + 1} 段正在生成`);
      return;
    }
  }
  // The changed content has not entered the synthesizer yet. Its next request
  // reads the replacement queue directly, so no active audio needs touching.
  setState(run.paused
    ? `稿件已同步，继续播放后从第 ${applyFrom + 1} 段使用新稿`
    : `稿件已更新；当前第 ${safeIndex + 1} 段继续播放，后续使用新稿`);
}

async function ask() {
  const option = document.querySelector('#vehicle').selectedOptions[0];
  const r = await api('/query', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({question:document.querySelector('#question').value, brand:option?.dataset.brand || '', series:option?.dataset.series || '', year:option?.dataset.year || ''})});
  currentAnswer = r.answer; document.querySelector('#answer').innerHTML = `<div class="notice">${esc(r.answer)}</div>${r.sources.map(s => `<div class="source">${esc(s.document_name)} · 相关度 ${Math.round(s.score * 100)}% · ${esc(s.metadata.series || '')}</div>`).join('')}`;
}

async function speakText(text) {
  const speakable = normalizeSpeechText(text);
  const q = sentenceList(speakable);
  if (!q.length) return;
  if (ttsMode === 'gpt-sovits') await startGptRun(q); else startBrowserRun(q);
}

function ttsBody(text, unitized = false) {
  const body = {text, unitized, voice_id:document.querySelector('#voice').value, speed_factor:Number(document.querySelector('#speed').value), top_k:15};
  if (!document.querySelector('#autoProsody')?.checked) {
    body.top_p = 0.9;
    body.temperature = Number(document.querySelector('#temperature')?.value || 0.75);
    body.repetition_penalty = Number(document.querySelector('#repetition')?.value || 1.3);
  }
  return JSON.stringify(body);
}

async function startQualityPreview(text) {
  stopLive();
  const run = createLiveRun('preview', [text]);
  liveRun = run;
  try {
    await ensureAudio();
    setState('GPT-SoVITS 高质量试听合成中…');
    const controller = new AbortController();
    run.abortController = controller;
    const response = await fetch(API + '/tts/synthesize', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:ttsBody(text),
      signal:controller.signal,
    });
    if (!response.ok) throw new Error(`TTS HTTP ${response.status} ${(await response.text()).slice(0, 120)}`);
    const audioData = await response.arrayBuffer();
    if (run.stopped || liveRun !== run) return;
    const buffer = await audioCtx.decodeAudioData(audioData);
    if (run.stopped || liveRun !== run) return;
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = Math.pow(2, Number(document.querySelector('#pitch')?.value || 0) / 12);
    source.connect(gainNode);
    gainNode.gain.value = Number(document.querySelector('#volume')?.value || 1);
    run.sources.add(source);
    activeSource = source;
    source.onended = () => {
      run.sources.delete(source);
      if (activeSource === source) activeSource = null;
      if (liveRun === run) {
        liveRun = null;
        setState('试听完成');
      }
    };
    source.start(audioCtx.currentTime + STREAM_LEAD_SECONDS);
    setState('正在试听当前音色');
  } catch (error) {
    if (!run.stopped && error.name !== 'AbortError') setState('试听失败：' + error.message);
    if (liveRun === run && !run.sources.size) liveRun = null;
  } finally {
    if (run.abortController) run.abortController = null;
  }
}

async function previewVoice() {
  const text = document.querySelector('#voicePreviewText')?.value.trim();
  if (!text) return;
  await startQualityPreview(normalizeSpeechText(text));
}

async function readScriptFile(event) { const file = event.target.files[0]; if (file) { document.querySelector('#script').value = await file.text(); renderScriptUnits(); } }
async function generateScript() { const option = document.querySelector('#vehicle').selectedOptions[0]; const points = prompt('请输入车型卖点，例如：580公里续航、激光雷达、智能泊车'); if (!points) return; const result = await api('/script/generate', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({brand:option?.dataset.brand || '欧拉', series:option?.dataset.series || '欧拉5 EV', year:option?.dataset.year || '2026', selling_points:points})}); document.querySelector('#script').value = result.script; renderScriptUnits(); setState('已生成新直播稿，请点击“应用动态改稿”'); }

function updatePromptMeta() {
  const node = document.querySelector('#voicePromptMeta');
  const input = document.querySelector('#voicePrompt');
  if (!node || !input) return;
  const core = input.value.replace(/[\s\p{P}\p{S}]+/gu, '');
  node.textContent = `${core.length} 个有效字 · 必须与录音逐字一致`;
  node.classList.toggle('warning', core.length > 0 && core.length < 4);
}

async function inspectVoiceFile() {
  const input = document.querySelector('#voiceFile');
  const node = document.querySelector('#voiceFileMeta');
  const file = input?.files?.[0];
  if (!node) return;
  if (!file) { node.textContent = '3-10 秒，主参考音频必须填写对应原文'; return; }
  const suffix = file.name.split('.').pop()?.toLowerCase() || '';
  const localUrl = URL.createObjectURL(file);
  const audio = new Audio();
  audio.preload = 'metadata';
  audio.src = localUrl;
  try {
    await new Promise((resolve, reject) => { audio.onloadedmetadata = resolve; audio.onerror = reject; });
    const duration = Number(audio.duration);
    input.dataset.duration = String(duration);
    const warning = duration < 3 || duration > 10 ? ' · 时长不在 3-10 秒建议范围' : '';
    node.textContent = `${file.name} · ${duration.toFixed(1)} 秒 · ${(file.size / 1024).toFixed(0)} KB${warning}`;
    node.classList.toggle('warning', Boolean(warning));
  } catch {
    input.dataset.duration = '';
    node.textContent = `${file.name} · ${suffix.toUpperCase()}，等待服务端检查音频`;
    node.classList.remove('warning');
  } finally { URL.revokeObjectURL(localUrl); }
}

function inspectAuxFiles() {
  const input = document.querySelector('#voiceAuxFiles');
  const node = document.querySelector('#voiceAuxMeta');
  if (!input || !node) return;
  const files = [...(input.files || [])];
  if (!files.length) {
    node.textContent = '最多 2 条；同一说话人的不同句子，不需要填写文字';
    node.classList.remove('warning');
    return;
  }
  const warning = files.length > 2;
  node.textContent = `${files.length} 条辅助参考${warning ? ' · 最多只能使用 2 条' : ' · 将用于同一说话人的音色融合'}`;
  node.classList.toggle('warning', warning);
}

function cloneUpload(form, onProgress) {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open('POST', API + '/voices/clone');
    request.responseType = 'json';
    request.upload.onprogress = event => { if (event.lengthComputable) onProgress(Math.round(event.loaded / event.total * 100)); };
    request.onerror = () => reject(new Error('无法连接后端服务，请确认项目已启动'));
    request.onload = () => {
      const body = request.response || {};
      if (request.status >= 200 && request.status < 300) return resolve(body);
      reject(new Error(body.detail || `音色克隆失败（HTTP ${request.status}）`));
    };
    request.send(form);
  });
}

async function analyzeVoiceSample() {
  const file = document.querySelector('#voiceFile')?.files?.[0];
  const auxiliary = [...(document.querySelector('#voiceAuxFiles')?.files || [])];
  const prompt = document.querySelector('#voicePrompt')?.value.trim() || '';
  if (!file) return setState('请先选择参考音频');
  const state = document.querySelector('#cloneState');
  state.textContent = '正在检查音频质量…';
  const form = new FormData();
  form.append('sample', file);
  auxiliary.slice(0, 2).forEach(item => form.append('aux_samples', item));
  form.append('prompt_text', prompt);
  try {
    const result = await api('/voices/analyze', {method:'POST', body:form});
    const advice = result.prompt_advice?.message ? `；${result.prompt_advice.message}` : '';
    state.textContent = `${result.quality?.message || result.recommendation}${advice}`;
    state.classList.toggle('warning', result.status !== 'ready' || result.prompt_advice?.status === 'review');
  } catch (error) { state.textContent = error.message; state.classList.add('warning'); }
}

async function waitForVoiceWarmup(voiceId) {
  const state = document.querySelector('#cloneState');
  for (let attempt = 0; attempt < 180; attempt += 1) {
    try {
      const voices = await api('/voices');
      const voice = voices.find(item => item.id === voiceId);
      if (voice && voice.warmed && !voice.warming) {
        if (state) { state.textContent = voice.calibrating ? '音色已预热，可直接试听；正在后台优化音色' : '音色已预热，可直接试听或用于直播'; state.classList.remove('warning'); }
        return true;
      }
      if (state) state.textContent = voice?.calibrating ? `音色已创建，正在自动校准音色… ${Math.min(99, attempt + 1)}%` : `音色已创建，正在预热克隆模型… ${Math.min(99, attempt + 1)}%`;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  if (state) state.textContent = '音色已保存；预热仍在进行，可稍后试听';
  return false;
}

async function cloneVoice() {
  const file = document.querySelector('#voiceFile')?.files?.[0];
  const auxiliary = [...(document.querySelector('#voiceAuxFiles')?.files || [])];
  const prompt = document.querySelector('#voicePrompt')?.value.trim() || '';
  const promptCore = prompt.replace(/[\s\p{P}\p{S}]+/gu, '');
  if (!file) return alert('请选择真人语音样本');
  if (auxiliary.length > 2) return alert('辅助参考音频最多选择 2 条');
  if (promptCore.length < 4) return alert('请填写至少 4 个字且与录音逐字一致的参考文本');
  const duration = Number(document.querySelector('#voiceFile')?.dataset.duration || 0);
  if (duration && (duration < 3 || duration > 10) && !confirm('当前样本不在建议的 3-10 秒范围内，继续创建可能降低音色稳定性。仍要继续吗？')) return;
  const form = new FormData();
  form.append('sample', file);
  auxiliary.forEach(item => form.append('aux_samples', item));
  form.append('name', document.querySelector('#voiceName').value.trim() || '我的主播');
  form.append('style', document.querySelector('#voiceStyle').value.trim() || '亲民');
  form.append('prompt_text', prompt);
  const state = document.querySelector('#cloneState');
  const progress = document.querySelector('#voiceProgress');
  const button = document.querySelector('#clone');
  button.disabled = true;
  progress.hidden = false; progress.value = 0;
  state.classList.remove('warning'); state.textContent = '上传参考音频…';
  try {
    const result = await cloneUpload(form, value => { progress.value = value; state.textContent = value >= 100 ? '音频已上传，正在生成标准 PCM 并预热…' : `上传参考音频… ${value}%`; });
    await studio();
    const select = document.querySelector('#voice');
    if (select) select.value = result.id;
    state.textContent = result.quality_hint || '音色已创建，正在预热…';
    await waitForVoiceWarmup(result.id);
  } catch (error) { state.textContent = error.message; state.classList.add('warning'); }
  finally { button.disabled = false; progress.hidden = true; }
}

async function tests() { layout('性能与验收', '查看检索、最终问答和流式 TTS 的可复现指标。', '<div id="testResult" class="metrics test-metrics"><div class="notice">测试中…</div></div>'); const [rag, qa, tts] = await Promise.all([api('/tests/retrieval', {method:'POST'}), api('/tests/qa', {method:'POST'}), api('/tests/tts', {method:'POST'})]); document.querySelector('#testResult').innerHTML = `<div class="metric"><b>${rag.accuracy}%</b><span>检索准确率（${rag.total}条样本）</span></div><div class="metric"><b>${qa.accuracy}%</b><span>最终问答准确率（${qa.total}条样本）</span></div><div class="metric"><b>${qa.meets_target ? '达标' : '需优化'}</b><span>问答 85% 目标</span></div><div class="metric"><b>${tts.average_first_audio_ms ?? '-'} ms</b><span>TTS平均首音频</span></div><div class="metric"><b>${tts.meets_target ? '达标' : '需优化'}</b><span>3秒延迟目标</span></div>`; }

document.querySelectorAll('nav button').forEach(button => button.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.toggle('active', x === button));
  ({knowledge,studio,tests}[button.dataset.view])().catch(showViewError);
});
document.querySelector('nav button').classList.add('active');
knowledge().catch(showViewError);
startHealthMonitor();
