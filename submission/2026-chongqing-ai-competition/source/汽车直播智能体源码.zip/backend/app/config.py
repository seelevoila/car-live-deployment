from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]

class Settings(BaseSettings):
    database_path: Path = ROOT / "data" / "car_live.db"
    upload_dir: Path = ROOT / "data" / "uploads"
    sample_dir: Path = ROOT / "data" / "sample"
    testset_path: Path = ROOT / "data" / "testset" / "retrieval_questions.json"
    llm_provider: str = "local"
    llm_base_url: str = ""
    llm_api_key: str = ""
    llm_model: str = ""
    gpt_sovits_url: str = ""
    gpt_sovits_ref_audio: str = ""
    gpt_sovits_prompt_text: str = ""
    gpt_sovits_prompt_language: str = "zh"
    gpt_sovits_text_language: str = "zh"
    gpt_sovits_model_version: str = "v2ProPlus"
    # Optional post-clone speaker-embedding calibration.  It runs in the
    # GPT-SoVITS environment and falls back to deterministic inference when
    # that environment or its speaker encoder is unavailable.
    gpt_sovits_calibration_enabled: bool = True
    gpt_sovits_python: str = str(ROOT.parent / "GPT-SoVITS" / ".venv" / "Scripts" / "python.exe")
    gpt_sovits_speaker_model: str = str(ROOT.parent / "GPT-SoVITS" / "GPT_SoVITS" / "pretrained_models" / "sv" / "pretrained_eres2netv2w24s4ep4.ckpt")
    gpt_sovits_aux_similarity_threshold: float = 0.85
    # The API process holds one GPT-SoVITS model at a time.  Keep the base
    # v2ProPlus pair available for newly cloned voices and the optional Xilian
    # fine-tune pair for the trained Xilian voice only.
    gpt_sovits_base_gpt_weights: str = str(ROOT.parent / "GPT-SoVITS" / "GPT_SoVITS" / "pretrained_models" / "s1v3.ckpt")
    gpt_sovits_base_sovits_weights: str = str(ROOT.parent / "GPT-SoVITS" / "GPT_SoVITS" / "pretrained_models" / "v2Pro" / "s2Gv2ProPlus.pth")
    gpt_sovits_xilian_gpt_weights: str = str(ROOT / "artifacts" / "xilian-dataset" / "weights" / "xilian_v2pro-e10.ckpt")
    gpt_sovits_xilian_sovits_weights: str = str(ROOT / "artifacts" / "xilian-dataset" / "weights" / "xilian_v2pro_e6_s588.pth")
    # Mode 1 returns quality-first fragments with clean phrase boundaries.  It
    # avoids SOLA overlap clicks while still allowing the browser to start
    # playing before the entire short phrase has finished generating.
    gpt_sovits_streaming_mode: int = 1
    max_document_bytes: int = 25 * 1024 * 1024
    max_audio_bytes: int = 50 * 1024 * 1024
    model_config = SettingsConfigDict(env_file=ROOT / "backend" / ".env", extra="ignore")

settings = Settings()
