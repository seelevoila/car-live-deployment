import asyncio
import json
import math
import re
import shutil
import sqlite3
import struct
import subprocess
import threading
import time
import wave
import zlib
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List
from uuid import uuid4

import httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from .config import settings
from .db import conn, init_db, now
from .rag import split_text, tokens, retrieve


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    with conn() as c:
        count = c.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    if count == 0:
        for path in sorted(settings.sample_dir.glob("*.txt")):
            ingest(path, path.name, "欧拉", "欧拉5 EV", "2026")
    threading.Thread(target=_warmup_tts, name="gpt-sovits-warmup", daemon=True).start()
    yield


app = FastAPI(title="汽车直播智能体", version="0.3.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class Query(BaseModel):
    question: str = Field(min_length=2)
    brand: str = ""
    series: str = ""
    year: str = ""
    top_k: int = Field(default=5, ge=1, le=20)


class Session(BaseModel):
    vehicle: str = Field(default="", max_length=200)
    script: str = Field(default="", max_length=20000)
    voice_id: str = "browser-default"


class Revision(BaseModel):
    script: str = Field(min_length=1, max_length=20000)
    sentence: int = Field(default=0, ge=0)


class State(BaseModel):
    status: str
    sentence: int = Field(default=0, ge=0)


class TTSRequest(BaseModel):
    # The live UI sends short units, while the API also supports direct long
    # requests and splits them at natural pauses server-side. `unitized` is
    # true only when the caller already applied the UI's punctuation-aware
    # queueing rules; in that case the server must preserve the unit intact.
    text: str = Field(min_length=1, max_length=20000)
    voice_id: str = "steady"
    unitized: bool = False
    speed_factor: float = Field(default=1.0, ge=0.6, le=1.6)
    # Conservative defaults are important for short reference cloning.  A
    # high-temperature sample can suddenly jump an octave even when the
    # speaker identity is otherwise correct.
    top_k: int = Field(default=15, ge=1, le=30)
    # ``None`` means "use the profile calibrated for this reference voice".
    # Callers can still supply explicit values for deliberate manual tuning.
    top_p: float | None = Field(default=None, ge=0.1, le=1.0)
    temperature: float | None = Field(default=None, ge=0.1, le=2.0)
    repetition_penalty: float | None = Field(default=None, ge=0.5, le=3.0)


class VoiceUpdate(BaseModel):
    name: str | None = None
    style: str | None = None
    prompt_text: str | None = None
    prompt_lang: str | None = None


class ScriptRequest(BaseModel):
    brand: str = "欧拉"
    series: str = "欧拉5 EV"
    year: str = "2026"
    selling_points: str = Field(min_length=2)


ALLOWED_DOCS = {".pdf", ".docx", ".txt"}
ALLOWED_AUDIO = {".wav", ".mp3", ".flac", ".ogg", ".m4a"}
REFERENCE_MIN_SECONDS = 3.0
REFERENCE_MAX_SECONDS = 10.0
MAX_AUX_REFERENCE_AUDIO = 2
CALIBRATION_TEXT = "你好，欢迎来到直播间。"
CALIBRATION_VERSION = 4
DEFAULT_SAMPLING_PROFILE = {"top_p": 0.9, "temperature": 0.75, "repetition_penalty": 1.3}
# Keep calibration to three short generations. Each candidate explores a seed
# and a sampling regime at once, so prosody-aware selection remains a
# background optimization rather than a user-facing clone delay.
CALIBRATION_CANDIDATES = (
    # GPT-SoVITS' official defaults preserve the reference speaker more
    # strongly for some lower-pitched voices.  Keep this candidate in the
    # generic pool instead of applying a gender-specific hard-coded profile.
    {"label": "official", "seed_offset": 0, "top_p": 1.00, "temperature": 1.00, "repetition_penalty": 1.30},
    {"label": "balanced", "seed_offset": 0, "top_p": 0.90, "temperature": 0.75},
    {"label": "stable", "seed_offset": 7919, "top_p": 0.82, "temperature": 0.62},
)
TTS_LOCK = threading.Lock()
_ACTIVE_MODEL_PROFILE = None
_TTS_LAST_SUCCESS_AT = 0.0
TTS_WARMUP = threading.Event()
VOICE_WARMING = set()
VOICE_WARMED = set()
VOICE_CALIBRATING = set()
VOICE_STYLE_PROFILES = {
    # Preset styles intentionally reuse the validated cloned reference while
    # shaping delivery. This keeps one-click presets compatible with the live
    # GPT-SoVITS path instead of silently switching to Web Speech.
    "steady": {"speed": 0.94, "temperature": -0.10, "repetition": 0.08},
    "energetic": {"speed": 1.05, "temperature": 0.10, "repetition": -0.05},
    "friendly": {"speed": 1.00, "temperature": 0.00, "repetition": 0.00},
}


def _tts_has_reference():
    if not settings.gpt_sovits_url:
        return False
    if settings.gpt_sovits_ref_audio and Path(settings.gpt_sovits_ref_audio).is_file():
        quality = _audio_quality(settings.gpt_sovits_ref_audio)
        if quality.get("status") in {"ready", "unverified"}:
            return True
    try:
        with conn() as c:
            rows = c.execute("SELECT reference_path,prompt_text FROM voices WHERE reference_path<>''").fetchall()
        return any(
            row[1].strip() and Path(row[0]).is_file() and _audio_quality(row[0]).get("status") == "ready"
            for row in rows
        )
    except Exception:
        return False


def _gpt_sovits_reachable():
    # GPT-SoVITS runs one inference worker. During clone calibration its HTTP
    # loop can be busy long enough for a separate /docs probe to time out even
    # though synthesis is healthy. Preserve a recent proven success so a page
    # refresh cannot incorrectly switch the studio to browser speech.
    if not settings.gpt_sovits_url:
        return False
    if time.monotonic() - _TTS_LAST_SUCCESS_AT < 300:
        return True
    base = settings.gpt_sovits_url.rstrip("/")
    if base.endswith("/tts"):
        base = base[:-4]
    try:
        with httpx.Client(timeout=1.5, trust_env=False) as client:
            return client.get(base + "/docs").is_success
    except httpx.HTTPError:
        return False


def _mark_tts_success():
    global _TTS_LAST_SUCCESS_AT
    _TTS_LAST_SUCCESS_AT = time.monotonic()


def _tts_is_ready():
    return _tts_has_reference() and _gpt_sovits_reachable()


def extract(path: Path):
    if path.suffix.lower() == ".txt":
        return [(None, path.read_text(encoding="utf-8-sig", errors="ignore"))]
    if path.suffix.lower() == ".docx":
        from docx import Document

        d = Document(path)
        blocks = [p.text.strip() for p in d.paragraphs if p.text.strip()]
        for table in d.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    blocks.append(" | ".join(c for c in cells if c))
        return [(None, "\n".join(blocks))]
    if path.suffix.lower() == ".pdf":
        import fitz

        with fitz.open(path) as d:
            return [(i + 1, p.get_text()) for i, p in enumerate(d)]
    raise ValueError("仅支持 PDF、DOCX、TXT")


def _write_chunks(c, document_id, source):
    count = 0
    for page, text in extract(source):
        for chunk in split_text(text):
            c.execute(
                "INSERT INTO chunks(document_id,content,tokens,page) VALUES(?,?,?,?)",
                (document_id, chunk, " ".join(tokens(chunk)), page),
            )
            count += 1
    if count == 0:
        raise ValueError("资料内容为空，无法建立知识片段")
    return count


def ingest(source: Path, name: str, brand: str = "", series: str = "", year: str = ""):
    created = now()
    with conn() as c:
        cur = c.execute(
            "INSERT INTO documents(name,path,type,size,brand,series,year,chunks,version,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (name, str(source), source.suffix[1:].upper(), source.stat().st_size, brand, series, year, 0, 1, created, created),
        )
        did = cur.lastrowid
        count = _write_chunks(c, did, source)
        c.execute("UPDATE documents SET chunks=? WHERE id=?", (count, did))
        c.execute(
            "INSERT INTO document_versions(document_id,version,name,path,size,chunks,created_at) VALUES(?,?,?,?,?,?,?)",
            (did, 1, name, str(source), source.stat().st_size, count, created),
        )
    return did


def replace_document(did: int, source: Path, name: str, brand: str, series: str, year: str):
    with conn() as c:
        row = c.execute("SELECT version FROM documents WHERE id=?", (did,)).fetchone()
        if not row:
            raise HTTPException(404, "资料不存在")
        version = int(row["version"]) + 1
        c.execute("DELETE FROM chunks WHERE document_id=?", (did,))
        count = _write_chunks(c, did, source)
        updated = now()
        c.execute(
            "UPDATE documents SET name=?,path=?,type=?,size=?,brand=?,series=?,year=?,chunks=?,version=?,updated_at=? WHERE id=?",
            (name, str(source), source.suffix[1:].upper(), source.stat().st_size, brand, series, year, count, version, updated, did),
        )
        c.execute(
            "INSERT INTO document_versions(document_id,version,name,path,size,chunks,created_at) VALUES(?,?,?,?,?,?,?)",
            (did, version, name, str(source), source.stat().st_size, count, updated),
        )
    return did


def _warmup_tts():
    """Warm the model and each usable clone so the first live phrase is not cold."""
    if not settings.gpt_sovits_url:
        TTS_WARMUP.set()
        return
    try:
        warmed = set()
        for _ in range(20):
            try:
                voices = []
                with conn() as c:
                    rows = c.execute("SELECT id,prompt_text,reference_path FROM voices WHERE reference_path<>'' ORDER BY created_at DESC").fetchall()
                for row in rows:
                    if row[1].strip() and row[2] and _audio_quality(row[2]).get("status") == "ready":
                        voices.append((row[0], "你好，欢迎来到直播间。"))
                if not voices:
                    voices = [("steady", "你好。")]
                with httpx.Client(timeout=120, trust_env=False) as client:
                    for voice_id, text in voices:
                        if voice_id in warmed or voice_id in VOICE_WARMED:
                            continue
                        request = TTSRequest(text=text, voice_id=voice_id)
                        VOICE_WARMING.add(voice_id)
                        try:
                            with TTS_LOCK:
                                _ensure_model_profile_loaded(_voice_model_profile(voice_id), client)
                                # Use the official POST JSON endpoint.  The
                                # GET route cannot reliably deserialize
                                # ``aux_ref_audio_paths`` as a list, so
                                # multi-reference clones silently fell back to
                                # the primary clip only.
                                with client.stream("POST", _tts_endpoint(), json=_tts_params(request, streaming=True)) as response:
                                    response.raise_for_status()
                                    received = sum(len(chunk) for chunk in response.iter_raw(8192))
                        finally:
                            VOICE_WARMING.discard(voice_id)
                        if received > 128:
                            _mark_tts_success()
                            warmed.add(voice_id)
                            VOICE_WARMED.add(voice_id)
                            _schedule_voice_calibration(voice_id)
                if warmed and len(warmed) >= len(voices):
                    # Leave the process on the base pair.  New uploads are the
                    # common live path, and this removes a model-swap penalty
                    # from their first phrase after startup.
                    with TTS_LOCK:
                        with httpx.Client(timeout=120, trust_env=False) as client:
                            _ensure_model_profile_loaded("base", client)
                    return
            except Exception:
                pass
            time.sleep(2)
    finally:
        TTS_WARMUP.set()


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "汽车直播智能体", "version": "0.3.0"}


@app.get("/api/config/status")
def config():
    gpt_ready = _tts_is_ready()
    llm_ready = bool(_llm_endpoint() and settings.llm_model)
    return {
        "llm": {"mode": "openai-compatible" if llm_ready else "local", "provider": "OpenAI-compatible" if llm_ready else "local-extractive", "ready": True, "enhanced": llm_ready},
        "tts": {"mode": "gpt-sovits" if gpt_ready else "browser", "provider": "GPT-SoVITS" if gpt_ready else "Web Speech API", "ready": gpt_ready},
        "retrieval": {"mode": "local", "provider": "SQLite hybrid", "ready": True},
    }


@app.get("/api/tts/status")
def tts_status():
    configured = _tts_has_reference()
    reachable = _gpt_sovits_reachable()
    ready = configured and reachable
    with conn() as c:
        rows = c.execute("SELECT reference_path,prompt_text FROM voices WHERE reference_path<>''").fetchall()
    cloned = sum(
        bool(row[1].strip() and Path(row[0]).is_file() and _audio_quality(row[0]).get("status") == "ready")
        for row in rows
    )
    return {
        "provider": "gpt-sovits" if ready else "browser",
        "ready": ready,
        "configured": configured,
        "reachable": reachable,
        "cloned_voices": cloned,
        "endpoint": settings.gpt_sovits_url or None,
        "model_version": settings.gpt_sovits_model_version,
        "streaming": ready,
        "stream_mode": "pcm-wav-natural",
        "streaming_mode": settings.gpt_sovits_streaming_mode,
        "active_model_profile": _ACTIVE_MODEL_PROFILE or "unknown",
        "model_profiles": ["base", "xilian"],
        "warming_up": not TTS_WARMUP.is_set() or bool(VOICE_WARMING) or bool(VOICE_CALIBRATING),
        "warmed_voice_ids": sorted(VOICE_WARMED),
    }


def _audio_quality(path: str):
    """Inspect WAV references before they reach GPT-SoVITS.

    A surprising number of phone exports carry an MP4/AAC payload behind a
    .wav suffix. GPT-SoVITS may decode such a file, but speaker identity and
    prosody become noticeably worse. We report that state instead of silently
    accepting a misleading reference.
    """
    if not path:
        return {"status": "missing", "message": "未配置参考音频"}
    audio_path = Path(path)
    if not audio_path.exists():
        return {"status": "missing", "message": "参考音频文件不存在"}
    if audio_path.suffix.lower() != ".wav":
        return {"status": "unverified", "message": "非 WAV 格式，将由 GPT-SoVITS 解码"}
    try:
        with wave.open(str(audio_path), "rb") as stream:
            channels = stream.getnchannels()
            sample_width = stream.getsampwidth()
            sample_rate = stream.getframerate()
            duration = stream.getnframes() / float(sample_rate or 1)
            frames = stream.readframes(min(stream.getnframes(), sample_rate * 30))
    except (wave.Error, EOFError, OSError):
        return {"status": "invalid", "message": "不是标准 PCM WAV，请重新导出或上传 MP3/WAV 音频"}
    active_ratio = None
    rms_db = None
    peak_db = None
    longest_silence = None
    silence_ratio = None
    clipped_ratio = None
    if sample_width == 2 and frames:
        import array

        samples = array.array("h")
        samples.frombytes(frames)
        if samples:
            peak = max(abs(sample) for sample in samples) or 1
            rms = math.sqrt(sum(sample * sample for sample in samples) / len(samples)) or 1
            active_threshold = 32768 * (10 ** (-45 / 20))
            active_ratio = sum(abs(sample) >= active_threshold for sample in samples) / len(samples)
            clipped_ratio = sum(abs(sample) >= 32700 for sample in samples) / len(samples)
            rms_db = 20 * math.log10(rms / 32768)
            peak_db = 20 * math.log10(peak / 32768)
            # Long internal silence is copied by GPT-SoVITS as unnatural gaps.
            # Measure short RMS windows instead of individual samples so quiet
            # consonants are not mistaken for silence.
            frame_size = max(1, int(sample_rate * 0.02))
            quiet_threshold = 32768 * (10 ** (-42 / 20))
            quiet_frames = []
            for start in range(0, len(samples), frame_size):
                window = samples[start:start + frame_size]
                if not window:
                    continue
                window_rms = math.sqrt(sum(sample * sample for sample in window) / len(window))
                quiet_frames.append(window_rms < quiet_threshold)
            silence_ratio = sum(quiet_frames) / len(quiet_frames) if quiet_frames else 0
            longest_frames = current_frames = 0
            for is_quiet in quiet_frames:
                if is_quiet:
                    current_frames += 1
                    longest_frames = max(longest_frames, current_frames)
                else:
                    current_frames = 0
            longest_silence = longest_frames * 0.02
    issues = []
    if channels != 1:
        issues.append("建议单声道")
    if sample_width != 2:
        issues.append("建议 16-bit")
    if not 16000 <= sample_rate <= 48000:
        issues.append("采样率建议 16kHz-48kHz")
    if not REFERENCE_MIN_SECONDS <= duration <= REFERENCE_MAX_SECONDS:
        issues.append("时长建议 3-10 秒")
    if active_ratio is not None and active_ratio < 0.45:
        issues.append("有效人声比例偏低，建议去除长静音")
    if rms_db is not None and rms_db < -35:
        issues.append("人声音量偏低，建议统一响度")
    if longest_silence is not None and longest_silence > 0.55:
        issues.append("检测到过长内部静音，建议压缩停顿后再克隆")
    if clipped_ratio is not None and clipped_ratio > 0.01:
        issues.append("检测到录音削波失真，建议降低麦克风增益后重新录制")
    return {
        "status": "ready" if not issues else "needs-review",
        "message": "标准 PCM WAV" if not issues else "；".join(issues),
        "duration": round(duration, 2),
        "channels": channels,
        "sample_width": sample_width,
        "sample_rate": sample_rate,
        "active_ratio": round(active_ratio, 3) if active_ratio is not None else None,
        "silence_ratio": round(silence_ratio, 3) if silence_ratio is not None else None,
        "longest_silence": round(longest_silence, 2) if longest_silence is not None else None,
        "clipped_ratio": round(clipped_ratio, 4) if clipped_ratio is not None else None,
        "rms_db": round(rms_db, 1) if rms_db is not None else None,
        "peak_db": round(peak_db, 1) if peak_db is not None else None,
    }


def _ffmpeg_binary():
    candidates = [
        shutil.which("ffmpeg"),
        r"C:\Program Files\CanMV IDE K230\share\qtcreator\ffmpeg\windows\bin\ffmpeg.exe",
    ]
    return next((item for item in candidates if item and Path(item).is_file()), None)


def _decoded_peak_db(source: Path):
    """Measure decoded peak for compressed references (OGG/MP3/M4A)."""
    ffmpeg = _ffmpeg_binary()
    if not ffmpeg:
        return None
    try:
        completed = subprocess.run(
            [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(source),
             "-vn", "-ac", "1", "-ar", "24000", "-f", "s16le", "-"],
            capture_output=True, timeout=45,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode != 0 or not completed.stdout:
        return None
    import array

    samples = array.array("h")
    samples.frombytes(completed.stdout[: len(completed.stdout) - (len(completed.stdout) % 2)])
    peak = max((abs(sample) for sample in samples), default=0)
    return 20 * math.log10(peak / 32768) if peak else None


def _normalize_prompt_text(text: str):
    text = re.sub(r"\s+", " ", text or "").strip()
    if text and text[-1] not in "。！？；.!?;":
        text += "。"
    return text


def _prompt_alignment(prompt_text: str, duration: float | None):
    """Return non-blocking guidance when the transcript density looks wrong.

    GPT-SoVITS needs the supplied text to describe the reference audio exactly.
    We cannot prove semantic equality without ASR, but a speaking-rate check
    catches the common mistake of pasting a paragraph for a short clip.
    """
    if not prompt_text or not duration or duration <= 0:
        return {"status": "unknown", "message": "请确认参考文本与录音逐字一致"}
    speech_chars = len(re.sub(r"[\s\W_]+", "", prompt_text, flags=re.UNICODE))
    if not speech_chars:
        return {"status": "invalid", "message": "参考文本需要包含实际说出的汉字或数字"}
    chars_per_second = speech_chars / duration
    if chars_per_second < 1.4:
        return {"status": "review", "message": "参考文本相对录音偏短；请确认没有漏写句子或保留过长停顿", "chars_per_second": round(chars_per_second, 2)}
    if chars_per_second > 8.5:
        return {"status": "review", "message": "参考文本相对录音偏长；请确认没有粘贴未录入的内容", "chars_per_second": round(chars_per_second, 2)}
    return {"status": "ok", "message": "参考文本长度与录音时长匹配", "chars_per_second": round(chars_per_second, 2)}


def _original_reference_audio(source: Path) -> Path:
    """Resolve a generated reference derivative back to its uploaded source."""
    stem = source.stem
    base = stem
    bases = [stem]
    derivative = re.compile(r"(?:\.normalized|\.clean|\.optimized\d*|\.processed|\.denoised|\.lite)$", re.IGNORECASE)
    while True:
        stripped = derivative.sub("", base)
        if stripped == base:
            break
        base = stripped
        bases.append(base)
    if len(bases) == 1:
        return source
    for candidate_base in sorted(set(bases), key=len):
        for suffix in sorted(ALLOWED_AUDIO):
            candidate = source.with_name(candidate_base + suffix)
            if candidate.is_file():
                return candidate
    return source


def _normalize_reference_audio(source: Path, *, force: bool = True):
    """Create a model-compatible WAV while preserving the speaker recording.

    GPT-SoVITS already rescales and resamples the reference internally.  Fixed
    FFT denoising, low-pass filtering, loudness normalization, and aggressive
    silence removal are destructive here: they change formants and often turn
    a clean recording into the electronic hiss heard in the clone.  The
    preprocessing step therefore only removes clearly excessive silence,
    decodes the source, folds it to mono, and writes deterministic 24 kHz/
    16-bit PCM.
    """
    quality = _audio_quality(str(source))
    source_peak_db = quality.get("peak_db")
    if source_peak_db is None:
        source_peak_db = _decoded_peak_db(source)
    peak_requires_protection = source_peak_db is not None and source_peak_db > -3.0
    if (
        quality["status"] == "ready"
        and quality.get("channels") == 1
        and quality.get("sample_rate") == 24000
        and quality.get("sample_width") == 2
        and not peak_requires_protection
    ):
        return source
    ffmpeg = _ffmpeg_binary()
    if not ffmpeg:
        if quality["status"] == "ready":
            return source
        raise HTTPException(422, "找不到音频预处理工具，无法把参考音频转换为标准 PCM WAV")
    target = source.with_name(source.stem + ".optimized.wav")
    if target == source:
        target = source.with_name(source.stem + ".processed.wav")
    # Only remove clearly non-speech leading/trailing sections and pauses longer
    # than a normal Chinese phrase break.  A short pause remains part of the
    # speaker's prosody and must stay aligned with the supplied transcript.
    filter_graph = (
        "silenceremove=start_periods=1:start_duration=0.20:start_threshold=-45dB:"
        "stop_periods=-1:stop_duration=0.55:stop_threshold=-40dB:stop_silence=0.18"
    )
    # New phone exports in the project were peaking at 0 dBFS.  Keep their
    # spectral shape intact but leave 3 dB of headroom for the synthesizer.
    if peak_requires_protection:
        filter_graph += f",volume={-3.0 - source_peak_db:.2f}dB"
    try:
        completed = subprocess.run(
            [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", str(source),
             "-af", filter_graph, "-map_metadata", "-1", "-ac", "1", "-ar", "24000", "-sample_fmt", "s16", str(target)],
            capture_output=True, text=True, timeout=90,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        target.unlink(missing_ok=True)
        raise HTTPException(422, f"参考音频预处理失败：{exc}") from exc
    if completed.returncode != 0 or not target.is_file():
        target.unlink(missing_ok=True)
        detail = (completed.stderr or "未知错误").strip()[-300:]
        raise HTTPException(422, f"参考音频无法解码或预处理失败：{detail}")
    normalized_quality = _audio_quality(str(target))
    if normalized_quality["status"] == "invalid" or not normalized_quality.get("duration"):
        target.unlink(missing_ok=True)
        raise HTTPException(422, "参考音频预处理后仍不是有效 PCM WAV")
    if normalized_quality.get("duration", 0) < REFERENCE_MIN_SECONDS or normalized_quality.get("duration", 0) > REFERENCE_MAX_SECONDS:
        target.unlink(missing_ok=True)
        raise HTTPException(422, "参考音频有效时长需为 3-10 秒；请提供完整的单人录音")
    return target


def _calibrate_voice(voice_id: str):
    """Filter references and jointly select identity/prosody sampling."""
    if not settings.gpt_sovits_calibration_enabled or voice_id in VOICE_CALIBRATING:
        return None
    with conn() as c:
        row = c.execute(
            "SELECT reference_path,model_profile,sampling_seed,validated_aux_reference_paths,aux_reference_paths,prompt_text,"
            "sampling_top_p,sampling_temperature,sampling_model_version,calibration_details "
            "FROM voices WHERE id=?",
            (voice_id,),
        ).fetchone()
    try:
        calibration_details = json.loads(row[9] or "{}") if row else {}
    except (TypeError, ValueError):
        calibration_details = {}
    if not row or not row[0] or row[1] != "base" or (
        row[2] is not None and row[3] is not None and row[6] is not None and row[7] is not None
        and row[8] == settings.gpt_sovits_model_version and calibration_details.get("calibration_version") == CALIBRATION_VERSION
    ):
        return None
    script = Path(__file__).with_name("voice_similarity.py")
    python = Path(settings.gpt_sovits_python)
    checkpoint = Path(settings.gpt_sovits_speaker_model)
    if not (script.is_file() and python.is_file() and checkpoint.is_file()):
        return None
    try:
        raw_aux = json.loads(row[4] or "[]")
    except (TypeError, ValueError):
        raw_aux = []
    references = [row[0]] + [
        str(path) for path in raw_aux[:MAX_AUX_REFERENCE_AUDIO]
        if isinstance(path, str) and Path(path).is_file() and _audio_quality(path).get("status") == "ready"
    ]
    calibration_signature = (row[0], row[4] or "[]", row[5] or "")
    calibration_dir = settings.upload_dir / "voice-calibration"
    calibration_dir.mkdir(parents=True, exist_ok=True)
    base_seed = _voice_sampling_seed(voice_id)
    candidate_specs = [
        {
            "label": profile["label"],
            "seed": (base_seed + profile["seed_offset"]) & 0x7FFFFFFF,
            "top_p": profile["top_p"],
            "temperature": profile["temperature"],
            "repetition_penalty": DEFAULT_SAMPLING_PROFILE["repetition_penalty"],
        }
        for profile in CALIBRATION_CANDIDATES
    ]
    run_id = uuid4().hex[:10]
    request_path = calibration_dir / f"{voice_id}-{run_id}.json"
    candidate_dir = calibration_dir / f"{voice_id}-{run_id}"
    VOICE_CALIBRATING.add(voice_id)
    try:
        with TTS_LOCK:
            with httpx.Client(timeout=180, trust_env=False) as client:
                _ensure_model_profile_loaded(_voice_model_profile(voice_id), client)
            request = TTSRequest(text=CALIBRATION_TEXT, voice_id=voice_id)
            request_path.write_text(
                json.dumps(_tts_params(request, seed_override=base_seed), ensure_ascii=False),
                encoding="utf-8",
            )
            command = [
                str(python), str(script),
                "--gpt-root", str(python.parent.parent.parent),
                "--checkpoint", str(checkpoint),
                "--aux-threshold", str(settings.gpt_sovits_aux_similarity_threshold),
                "--endpoint", _tts_endpoint(),
                "--request-json", str(request_path),
                "--candidate-dir", str(candidate_dir),
            ]
            for reference in references:
                command.extend(("--reference", str(reference)))
            for candidate in candidate_specs:
                command.extend(("--candidate-spec", json.dumps(candidate, ensure_ascii=False)))
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=120,
            )
        if completed.returncode != 0:
            return None
        output = json.loads((completed.stdout or "").strip().splitlines()[-1])
        best_candidate = output.get("best_candidate") or {}
        best_sampling = best_candidate.get("sampling") or {}
        best_seed = int(best_sampling.get("seed", base_seed))
        best_top_p = float(best_sampling.get("top_p", DEFAULT_SAMPLING_PROFILE["top_p"]))
        best_temperature = float(best_sampling.get("temperature", DEFAULT_SAMPLING_PROFILE["temperature"]))
        accepted_aux = output.get("accepted_aux_paths", [])
        with conn() as c:
            current = c.execute(
                "SELECT reference_path,aux_reference_paths,prompt_text FROM voices WHERE id=?",
                (voice_id,),
            ).fetchone()
        if not current or (current[0], current[1] or "[]", current[2] or "") != calibration_signature:
            # The host edited the reference while this background run was in
            # flight. Never apply a result computed for the old speaker data.
            return None
        calibration_details = {
            "calibration_version": CALIBRATION_VERSION,
            "scores": output.get("scores", []),
            "reference_scores": output.get("reference_scores", []),
            "reference_prosody": output.get("reference_prosody", {}),
            "reference_prosody_risk": output.get("reference_prosody_risk", {}),
        }
        _save_voice_calibration(
            voice_id,
            best_seed,
            accepted_aux,
            top_p=best_top_p,
            temperature=best_temperature,
            details=calibration_details,
        )
        _mark_tts_success()
        return {
            "seed": best_seed,
            "top_p": best_top_p,
            "temperature": best_temperature,
            "scores": output.get("scores", []),
            "reference_scores": output.get("reference_scores", []),
            "accepted_aux_paths": accepted_aux,
        }
    except (OSError, ValueError, KeyError, IndexError, json.JSONDecodeError, httpx.HTTPError, subprocess.TimeoutExpired, sqlite3.Error):
        return None
    finally:
        VOICE_CALIBRATING.discard(voice_id)
        request_path.unlink(missing_ok=True)
        if candidate_dir.is_dir():
            for candidate_path in candidate_dir.glob("candidate-*.wav"):
                candidate_path.unlink(missing_ok=True)
        try:
            candidate_dir.rmdir()
        except OSError:
            pass


def _warm_single_voice(voice_id: str):
    """Fully drain one clone request so GPT-SoVITS caches its prompt features."""
    if voice_id in VOICE_WARMED or voice_id in VOICE_WARMING or not settings.gpt_sovits_url:
        return
    VOICE_WARMING.add(voice_id)
    try:
        request = TTSRequest(text="你好，欢迎来到直播间。", voice_id=voice_id)
        with TTS_LOCK:
            with httpx.Client(timeout=180, trust_env=False) as client:
                _ensure_model_profile_loaded(_voice_model_profile(voice_id), client)
                with client.stream("POST", _tts_endpoint(), json=_tts_params(request, streaming=True)) as response:
                    response.raise_for_status()
                    received = sum(len(chunk) for chunk in response.iter_raw(8192))
        if received > 128:
            _mark_tts_success()
            VOICE_WARMED.add(voice_id)
            # The first usable clone is ready now. Reference screening and
            # seed selection continue in the background so the UI does not
            # make the host wait for two extra synthesis passes.
            VOICE_WARMING.discard(voice_id)
            _schedule_voice_calibration(voice_id)
    except Exception:
        pass
    finally:
        VOICE_WARMING.discard(voice_id)


def _schedule_voice_calibration(voice_id: str):
    """Start calibration without making the first usable clone wait for it."""
    if voice_id in VOICE_CALIBRATING or not settings.gpt_sovits_calibration_enabled:
        return
    threading.Thread(
        target=_calibrate_voice,
        args=(voice_id,),
        name=f"calibrate-voice-{voice_id}",
        daemon=True,
    ).start()


def _voice_config(voice_id: str):
    with conn() as c:
        row = c.execute("SELECT * FROM voices WHERE id=?", (voice_id,)).fetchone()
    ref = row["reference_path"] if row and row["reference_path"] else settings.gpt_sovits_ref_audio
    prompt_text = row["prompt_text"] if row and row["prompt_text"] else settings.gpt_sovits_prompt_text
    prompt_text = _normalize_prompt_text(prompt_text)
    prompt_lang = row["prompt_lang"] if row and row["prompt_lang"] else settings.gpt_sovits_prompt_language
    # A deployment may keep the global reference setting empty and store the
    # usable reference only in the voice library. In that case direct API calls
    # using a preset/default id should still resolve to a valid cloned speaker.
    preset_reference_unusable = (
        (not row or not row["reference_path"])
        and (
            not prompt_text.strip()
            or _audio_quality(ref).get("status") in {"missing", "invalid", "needs-review"}
        )
    )
    if not ref or preset_reference_unusable:
        with conn() as c:
            fallback = c.execute(
                "SELECT reference_path,prompt_text,prompt_lang FROM voices "
                "WHERE reference_path<>'' AND TRIM(prompt_text)<>'' ORDER BY created_at DESC"
            ).fetchall()
        for candidate in fallback:
            candidate_quality = _audio_quality(candidate[0])
            if candidate_quality.get("status") == "ready":
                ref = candidate[0]
                prompt_text = _normalize_prompt_text(candidate[1])
                prompt_lang = candidate[2] or prompt_lang
                break
    if not ref:
        raise HTTPException(503, "尚未配置参考音频")
    # GPT-SoVITS can infer without prompt text, but supplying the real transcript is
    # the single biggest factor in retaining the uploaded speaker's pronunciation
    # and prosody. Do not silently fall back for an uploaded clone.
    if row and row["reference_path"] and not prompt_text.strip():
        raise HTTPException(422, "该克隆音色尚未填写参考音频原文，请补充与录音完全一致的文本后再播报")
    quality = _audio_quality(ref)
    if quality["status"] in {"invalid", "missing", "needs-review"}:
        raise HTTPException(422, f"参考音频格式无效：{quality['message']}")
    if row and row["reference_path"] and quality["status"] == "needs-review":
        raise HTTPException(422, f"参考音频需要优化后再播报：{quality['message']}")
    return ref, prompt_text, prompt_lang


def _voice_aux_reference_paths(voice_id: str):
    """Return validated auxiliary references for the selected speaker.

    GPT-SoVITS uses the first reference for semantic/prompt conditioning and
    these additional files for multi-reference timbre fusion.  Preset ids are
    resolved to the same fallback clone as ``_voice_config`` so the reference
    and auxiliary set can never come from different speakers.
    """
    row = None
    screened_column = True
    with conn() as c:
        try:
            row = c.execute(
                "SELECT reference_path,aux_reference_paths,validated_aux_reference_paths FROM voices WHERE id=?",
                (voice_id,),
            ).fetchone()
        except sqlite3.Error:
            screened_column = False
            row = c.execute(
                "SELECT reference_path,aux_reference_paths FROM voices WHERE id=?",
                (voice_id,),
            ).fetchone()
        if (not row or not row[0]) and settings.gpt_sovits_ref_audio:
            columns = "reference_path,aux_reference_paths,validated_aux_reference_paths" if screened_column else "reference_path,aux_reference_paths"
            row = c.execute(
                f"SELECT {columns} FROM voices WHERE reference_path=? LIMIT 1",
                (settings.gpt_sovits_ref_audio,),
            ).fetchone()
        if not row or not row[0]:
            columns = "reference_path,aux_reference_paths,validated_aux_reference_paths" if screened_column else "reference_path,aux_reference_paths"
            candidates = c.execute(
                f"SELECT {columns} FROM voices "
                "WHERE reference_path<>'' AND TRIM(prompt_text)<>'' ORDER BY created_at DESC"
            ).fetchall()
            for candidate in candidates:
                if _audio_quality(candidate[0]).get("status") == "ready":
                    row = candidate
                    break
    if not row:
        return []
    try:
        # NULL means a legacy/new voice that has not been screened yet. Use
        # only the transcript-bearing primary clip until screening completes;
        # averaging an unverified auxiliary can make the first usable preview
        # less like the speaker. An explicit [] means calibration rejected all
        # auxiliaries and must not silently fall back to averaging them again.
        encoded_paths = row[2] if screened_column and row[2] is not None else "[]" if screened_column else row[1]
        paths = json.loads(encoded_paths or "[]")
    except (TypeError, ValueError):
        paths = []
    if not isinstance(paths, list):
        return []
    return [
        str(path)
        for path in paths[:MAX_AUX_REFERENCE_AUDIO]
        if isinstance(path, str)
        and Path(path).is_file()
        and _audio_quality(path).get("status") == "ready"
    ]


def _voice_sampling_seed(voice_id: str):
    """Return one deterministic seed per speaker, independent of script text."""
    row = None
    try:
        with conn() as c:
            row = c.execute(
                "SELECT sampling_seed,reference_path FROM voices WHERE id=?",
                (voice_id,),
            ).fetchone()
            if not row or not row[1]:
                if settings.gpt_sovits_ref_audio:
                    row = c.execute(
                        "SELECT sampling_seed,reference_path FROM voices WHERE reference_path=? LIMIT 1",
                        (settings.gpt_sovits_ref_audio,),
                    ).fetchone()
                if not row or not row[1]:
                    candidates = c.execute(
                        "SELECT sampling_seed,reference_path FROM voices "
                        "WHERE reference_path<>'' AND TRIM(prompt_text)<>'' ORDER BY created_at DESC"
                    ).fetchall()
                    for candidate in candidates:
                        if _audio_quality(candidate[1]).get("status") == "ready":
                            row = candidate
                            break
    except sqlite3.Error:
        # Unit callers and older installations may reach inference before the
        # additive migration has run. The normal lifespan migrates before HTTP.
        row = None
    if row and row[0] is not None:
        return int(row[0]) & 0x7FFFFFFF
    identity = row[1] if row and row[1] else voice_id
    return zlib.crc32(f"voice-seed\0{identity}".encode("utf-8")) & 0x7FFFFFFF


def _voice_sampling_profile(voice_id: str):
    """Load the per-speaker stable sampler selected during clone calibration."""
    try:
        with conn() as c:
            row = c.execute(
                "SELECT sampling_top_p,sampling_temperature,sampling_model_version,calibration_details FROM voices WHERE id=?",
                (voice_id,),
            ).fetchone()
    except sqlite3.Error:
        row = None
    try:
        details = json.loads(row[3] or "{}") if row else {}
    except (TypeError, ValueError):
        details = {}
    if row and row[0] is not None and row[1] is not None and row[2] == settings.gpt_sovits_model_version and details.get("calibration_version") == CALIBRATION_VERSION:
        return {
            "top_p": max(0.1, min(1.0, float(row[0]))),
            "temperature": max(0.1, min(2.0, float(row[1]))),
            "repetition_penalty": DEFAULT_SAMPLING_PROFILE["repetition_penalty"],
            "calibrated": True,
        }
    return {**DEFAULT_SAMPLING_PROFILE, "calibrated": False}


def _save_voice_calibration(
    voice_id: str,
    seed: int,
    accepted_aux_paths: list[str],
    *,
    top_p: float = DEFAULT_SAMPLING_PROFILE["top_p"],
    temperature: float = DEFAULT_SAMPLING_PROFILE["temperature"],
    details: dict | None = None,
):
    with conn() as c:
        c.execute(
            "UPDATE voices SET sampling_seed=?,validated_aux_reference_paths=?,sampling_top_p=?,"
            "sampling_temperature=?,sampling_model_version=?,calibration_details=? WHERE id=?",
            (
                int(seed) & 0x7FFFFFFF,
                json.dumps(accepted_aux_paths, ensure_ascii=False),
                max(0.1, min(1.0, float(top_p))),
                max(0.1, min(2.0, float(temperature))),
                settings.gpt_sovits_model_version,
                json.dumps({"calibration_version": CALIBRATION_VERSION, **(details or {})}, ensure_ascii=False),
                voice_id,
            ),
        )


def _voice_model_profile(voice_id: str):
    """Resolve the model family for a voice without changing inference state."""
    with conn() as c:
        row = c.execute("SELECT model_profile,reference_path FROM voices WHERE id=?", (voice_id,)).fetchone()
    # Preset voices and newly uploaded samples use the v2ProPlus base model.  A
    # fine-tuned model is opt-in per database row so it cannot leak into other
    # speakers through GPT-SoVITS' process-global weight state.
    if not row or not row[1]:
        if settings.gpt_sovits_ref_audio:
            with conn() as c:
                global_row = c.execute(
                    "SELECT model_profile FROM voices WHERE reference_path=? LIMIT 1",
                    (settings.gpt_sovits_ref_audio,),
                ).fetchone()
            if global_row and global_row[0] in {"base", "xilian"}:
                return global_row[0]
        # Preset ids intentionally reuse the newest validated clone when no
        # global reference is configured. Resolve that same fallback here so
        # its reference and model family cannot get out of sync.
        with conn() as c:
            candidates = c.execute(
                "SELECT model_profile,reference_path FROM voices "
                "WHERE reference_path<>'' AND TRIM(prompt_text)<>'' ORDER BY created_at DESC"
            ).fetchall()
        for candidate in candidates:
            if _audio_quality(candidate[1]).get("status") == "ready":
                return candidate[0] if candidate[0] in {"base", "xilian"} else "base"
        return "base"
    return row[0] if row[0] in {"base", "xilian"} else "base"


def _model_profile_weights(profile: str):
    if profile == "xilian":
        return settings.gpt_sovits_xilian_gpt_weights, settings.gpt_sovits_xilian_sovits_weights
    return settings.gpt_sovits_base_gpt_weights, settings.gpt_sovits_base_sovits_weights


def _ensure_model_profile_loaded(profile: str, client: httpx.Client):
    """Load a model pair while TTS_LOCK is held.

    GPT-SoVITS keeps weights in global process state, so this is deliberately
    adjacent to every inference request.  The lock makes a weight swap and
    the following synthesis atomic with respect to streaming and preview.
    """
    global _ACTIVE_MODEL_PROFILE
    if not settings.gpt_sovits_url or _ACTIVE_MODEL_PROFILE == profile:
        return
    gpt_weights, sovits_weights = _model_profile_weights(profile)
    if not (Path(gpt_weights).is_file() and Path(sovits_weights).is_file()):
        raise HTTPException(503, f"{profile} 音色模型权重不存在，请检查 GPT-SoVITS 配置")
    base = settings.gpt_sovits_url.rstrip("/")
    try:
        for route, weights in (("/set_gpt_weights", gpt_weights), ("/set_sovits_weights", sovits_weights)):
            response = client.get(base + route, params={"weights_path": weights}, timeout=180)
            response.raise_for_status()
    except httpx.HTTPError as exc:
        raise HTTPException(503, f"切换 GPT-SoVITS {profile} 权重失败：{exc}") from exc
    _ACTIVE_MODEL_PROFILE = profile
    _mark_tts_success()


async def _ensure_model_profile_loaded_async(profile: str, client: httpx.AsyncClient):
    """Async counterpart used by the live streaming generator."""
    global _ACTIVE_MODEL_PROFILE
    if not settings.gpt_sovits_url or _ACTIVE_MODEL_PROFILE == profile:
        return
    gpt_weights, sovits_weights = _model_profile_weights(profile)
    if not (Path(gpt_weights).is_file() and Path(sovits_weights).is_file()):
        raise RuntimeError(f"{profile} 音色模型权重不存在，请检查 GPT-SoVITS 配置")
    base = settings.gpt_sovits_url.rstrip("/")
    try:
        for route, weights in (("/set_gpt_weights", gpt_weights), ("/set_sovits_weights", sovits_weights)):
            response = await client.get(base + route, params={"weights_path": weights}, timeout=180)
            response.raise_for_status()
    except httpx.HTTPError as exc:
        raise RuntimeError(f"切换 GPT-SoVITS {profile} 权重失败：{exc}") from exc
    _ACTIVE_MODEL_PROFILE = profile
    _mark_tts_success()


def _preferred_clone_voice_id():
    """Return the newest validated clone for warmup and acceptance checks."""
    with conn() as c:
        rows = c.execute(
            "SELECT id,reference_path,prompt_text FROM voices "
            "WHERE reference_path<>'' AND TRIM(prompt_text)<>'' ORDER BY created_at DESC"
        ).fetchall()
    for row in rows:
        if _audio_quality(row[1]).get("status") == "ready":
            return row[0]
    return "steady"


CN_DIGITS = "零一二三四五六七八九"


def _cn_section(number: int, *, omit_one_ten: bool = True) -> str:
    """Convert one 0..9999 section without duplicate or trailing 零."""
    if number == 0:
        return ""
    units = ("", "十", "百", "千")
    digits = list(reversed(f"{number:04d}"))
    out, pending_zero = [], False
    for index in range(3, -1, -1):
        digit = int(digits[index])
        if digit:
            if pending_zero and out:
                out.append("零")
            out.append(CN_DIGITS[digit] + units[index])
            pending_zero = False
        elif out:
            pending_zero = True
    result = "".join(out)
    # Only standalone 10–19 omit the leading 一; 110 must remain 一百一十.
    return result.replace("一十", "十", 1) if omit_one_ten and number < 20 else result


def _number_to_cn(value: str) -> str:
    """Use natural Chinese cardinal numbers; decimals read digit-by-digit."""
    if "." in value:
        left, right = value.split(".", 1)
        return _number_to_cn(left) + "点" + "".join(CN_DIGITS[int(x)] for x in right)
    number = int(value)
    if number == 0:
        return "零"
    sections = []
    while number:
        sections.append(number % 10000)
        number //= 10000
    result, need_zero = [], False
    big_units = ("", "万", "亿", "兆")
    for index in range(len(sections) - 1, -1, -1):
        section = sections[index]
        if not section:
            if result:
                need_zero = True
            continue
        if result and (need_zero or section < 1000):
            if result[-1] != "零":
                result.append("零")
        result.append(
            _cn_section(section, omit_one_ten=not result)
            + (big_units[index] if index < len(big_units) else "")
        )
        need_zero = False
    return "".join(result).replace("零零", "零").rstrip("零")


def normalize_tts_text(text: str) -> str:
    """Normalize once on the server; the browser must send the original text."""
    text = re.sub(r"^根据当前车型资料[:：]\s*", "", text.strip())
    text = re.sub(r"^根据资料[:：]\s*", "", text)

    # Dates first, otherwise the year/month/day would be converted independently.
    def date_replace(match):
        year, month, day = match.groups()
        return "".join(CN_DIGITS[int(x)] for x in year) + f"年{_number_to_cn(month)}月{_number_to_cn(day)}日"
    text = re.sub(r"(?<!\d)(19\d{2}|20\d{2})[-/]([01]?\d)[-/]([0-3]?\d)(?!\d)", date_replace, text)

    # Model years are conventionally read digit-by-digit: 二零二六款.
    text = re.sub(
        r"(?<!\d)(19\d{2}|20\d{2})(?=\s*(?:年|款|版|型号))",
        lambda m: "".join(CN_DIGITS[int(x)] for x in m.group(1)),
        text,
    )

    units = {
        "km/h": "公里每小时", "km": "公里", "kWh": "千瓦时", "kW": "千瓦", "N·m": "牛米", "Nm": "牛米",
        "%": "百分之", "L": "升", "万元": "万元", "万": "万元", "元": "元",
        "公里": "公里", "毫米": "毫米", "小时": "小时", "秒": "秒",
    }
    # Longest units first prevents 13.38万元 becoming “万元元”.
    unit_pattern = r"万元|km/h|kWh|N·m|公里|毫米|小时|秒|km|kW|Nm|%|L|万|元"
    pattern = re.compile(rf"(?<![\d点])(\d+(?:\.\d+)?)[ \t]*({unit_pattern})?", re.I)

    def replace(match):
        number, unit = match.group(1), match.group(2) or ""
        return _number_to_cn(number) + units.get(unit, unit)

    text = pattern.sub(replace, text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[:：]+", "，", text)
    text = re.sub(r"，{2,}", "，", text)
    return text.strip()


# Keep quantities and their units together when a long live sentence is split.
# Splitting `580km` into `580` + `km` makes the upstream model read the value
# as disconnected digits instead of the natural Chinese quantity.
_TTS_ATOMIC_TOKEN = re.compile(
    r"(?:\d+(?:\.\d+)?\s*(?:km/h|kWh|N·m|km|kW|Nm|公里|毫米|小时|秒|%|L|万元|万|元|年|款|版|型号|EV)?"
    r"|[零一二三四五六七八九十百千万亿兆点]+(?:公里每小时|千瓦时|牛米|公里|毫米|小时|秒|百分之|升|万元|元|年|款|版|型号|EV)?)",
    re.IGNORECASE,
)


def _safe_tts_cut(text: str, limit: int) -> int:
    """Return a split point that does not cut a number/unit token in half."""
    if len(text) <= limit:
        return len(text)
    end = max(1, limit)
    for match in _TTS_ATOMIC_TOKEN.finditer(text):
        if match.start() < end < match.end():
            # If the token starts the chunk, keep the whole token even when it
            # is slightly longer than the nominal chunk size.
            end = match.end() if match.start() == 0 else match.start()
            break
    return max(1, end)


def _tts_params(req: TTSRequest, *, streaming: bool = False, seed_override: int | None = None):
    ref, prompt_text, prompt_lang = _voice_config(req.voice_id)
    aux_refs = _voice_aux_reference_paths(req.voice_id)
    live_model_mode = settings.gpt_sovits_streaming_mode if streaming else False
    profile = VOICE_STYLE_PROFILES.get(req.voice_id, {})
    speed_factor = max(0.6, min(1.6, req.speed_factor * profile.get("speed", 1.0)))
    sampling = _voice_sampling_profile(req.voice_id)
    requested_top_p = sampling["top_p"] if req.top_p is None else req.top_p
    requested_temperature = sampling["temperature"] if req.temperature is None else req.temperature
    requested_repetition = sampling["repetition_penalty"] if req.repetition_penalty is None else req.repetition_penalty
    top_p = max(0.1, min(1.0, float(requested_top_p)))
    temperature = max(0.1, min(2.0, float(requested_temperature) + profile.get("temperature", 0.0)))
    repetition_penalty = max(0.5, min(3.0, float(requested_repetition) + profile.get("repetition", 0.0)))
    normalized_text = normalize_tts_text(req.text)
    # Keep one seed per speaker. A text-derived seed makes the same clone drift
    # between scripts; calibration can replace this stable fallback once it has
    # compared several candidates against the reference speaker embedding.
    seed = _voice_sampling_seed(req.voice_id) if seed_override is None else int(seed_override) & 0x7FFFFFFF
    return {
        "ref_audio_path": ref,
        "aux_ref_audio_paths": aux_refs,
        "prompt_text": prompt_text,
        "prompt_lang": prompt_lang,
        "text": normalized_text,
        "text_lang": settings.gpt_sovits_text_language,
        # The browser already feeds short, punctuation-aligned live units. Keeping
        # each unit intact avoids a second server-side split and makes revisions
        # take effect at the next natural pause.
        "text_split_method": "cut0" if streaming else "cut2",
        "media_type": "wav",
        # Mode 1 keeps the model's quality-first fragment path.  Unlike modes
        # 2/3 it does not SOLA-blend semantic chunks, so boundaries stay free of
        # the electronic clicks that were audible in the previous profile.
        "streaming_mode": live_model_mode,
        "top_k": req.top_k,
        "top_p": top_p,
        "temperature": temperature,
        "seed": seed,
        "speed_factor": speed_factor,
        # Full-phrase live requests can use the quality/faster parallel decoder;
        # true incremental modes must use the model's naive streaming decoder.
        "parallel_infer": False if live_model_mode else True,
        "repetition_penalty": repetition_penalty,
        # Both live fragments and quality preview audio already contain natural
        # punctuation pauses. Appending GPT-SoVITS' synthetic zero tail creates
        # an avoidable gap at every unit boundary.
        "fragment_interval": 0.0,
        "overlap_length": 2,
        # Slightly smaller semantic blocks keep short live units responsive;
        # mode 1 still uses the quality-first decoder and the browser applies
        # edge fades at each PCM buffer boundary.
        "min_chunk_length": 10 if streaming else 16,
    }


def _live_unit_params(req: TTSRequest, unit_index: int):
    """Keep every live unit on the incremental decoder.

    The previous quality-first exception for a long opening phrase buffered
    the entire unit before returning its first PCM bytes. That made a normal
    opening line take 10+ seconds to start, violating the competition's
    streaming/3-second requirement. Mode 1 is now used consistently for live
    units; the browser's short natural units and 2 ms edge fades preserve the
    clean boundaries without sacrificing first-audio latency.
    """
    return _tts_params(req, streaming=True)


def _tts_text_units(text: str, max_chars: int = 20):
    """Split live copy at natural pauses while keeping tiny lead-ins attached.

    A standalone two- or three-character opener is an especially weak cloning
    prompt. It tends to produce a clipped initial consonant and adds an extra
    request boundary, so short clauses are merged with the following clause
    within a bounded 48-character unit.
    """
    short_clause_chars = 10
    # Keep a short salutation attached to context without creating a long
    # first request that delays the first PCM fragment beyond three seconds.
    clause_merge_max = 20
    normalized = normalize_tts_text(text)
    raw = re.findall(r"[^。！？；.!?]+[。！？；.!?]?", normalized)
    units = []
    for sentence in raw or [normalized]:
        sentence = sentence.strip()
        if not sentence:
            continue
        clauses = re.findall(r"[^，,、：:]+[，,、：:]?", sentence)
        merged_clauses = []
        index = 0
        while index < len(clauses):
            clause = clauses[index].strip()
            following = clauses[index + 1].strip() if index + 1 < len(clauses) else ""
            short_lead = following and len(clause) < short_clause_chars and len(clause) + len(following) <= clause_merge_max
            natural_pair = following and len(clause) >= 10 and len(following) >= 10 and len(clause) + len(following) <= clause_merge_max
            if short_lead or natural_pair:
                combined = clause + following
                index += 2
                while index < len(clauses) and len(clauses[index].strip()) >= 10 and len(combined) + len(clauses[index].strip()) <= clause_merge_max:
                    combined += clauses[index].strip()
                    index += 1
                merged_clauses.append((combined, True))
                continue
            # If a salutation is followed by a long clause, still attach a
            # bounded phonetic context to it. A standalone "老板" is prone to
            # clipped initials, while sending the whole long clause defeats
            # the first-audio latency target.
            if following and len(clause) < short_clause_chars:
                room = clause_merge_max - len(clause) - 1  # reserve the pause comma
                prefix_end = _safe_tts_cut(following, max(1, room))
                prefix = following[:prefix_end].rstrip("，,、：:")
                if prefix:
                    merged_clauses.append((clause + prefix + "，", True))
                    remainder = following[prefix_end:].lstrip()
                    clauses[index + 1] = remainder
                    index += 1
                    continue
            merged_clauses.append((clause, False))
            index += 1
        if len(sentence) <= max_chars or len(clauses) <= 1:
            while len(sentence) > max_chars:
                cut = _safe_tts_cut(sentence, max_chars)
                units.append(sentence[:cut].rstrip("，,、：:") + "，")
                sentence = sentence[cut:].lstrip()
            if sentence:
                units.append(sentence)
            continue
        current = ""
        for clause, relaxed in merged_clauses:
            clause_limit = clause_merge_max if relaxed else max_chars + 6
            while len(clause) > clause_limit:
                if current:
                    units.append(current)
                    current = ""
                cut = _safe_tts_cut(clause, max_chars)
                units.append(clause[:cut].rstrip("，,、：:") + "，")
                clause = clause[cut:].lstrip()
            if current and len(current) + len(clause) > max_chars:
                units.append(current)
                current = ""
            current += clause
        if current:
            units.append(current)
    return units or ([normalized] if normalized else [])


def _tts_stream_units(req: TTSRequest):
    """Resolve stream units once, without splitting an already queued phrase.

    The browser owns live queue boundaries because it also uses them for
    progress, playback scheduling, and safe dynamic revisions. Direct API
    callers can omit ``unitized`` and retain the server-side fallback splitter.
    """
    if req.unitized:
        normalized = normalize_tts_text(req.text)
        return [normalized] if normalized else []
    return _tts_text_units(req.text)


def _wav_data_offset(buffer: bytes):
    """Return the PCM data offset once a complete WAV header is buffered."""
    if len(buffer) < 4:
        return None
    if buffer[:4] != b"RIFF":
        raise ValueError("上游返回的不是 WAV 音频")
    if len(buffer) < 12:
        return None
    if buffer[8:12] != b"WAVE":
        raise ValueError("上游返回的不是 WAV 音频")
    offset = 12
    while offset + 8 <= len(buffer):
        chunk_size = struct.unpack_from("<I", buffer, offset + 4)[0]
        body = offset + 8
        if body + chunk_size > len(buffer):
            return None
        if buffer[offset:offset + 4] == b"data":
            return body
        offset = body + chunk_size + (chunk_size % 2)
    return None


def _iter_pcm_wav_payload(chunks, *, include_header: bool):
    """Yield PCM bytes from one complete/streaming WAV response.

    GPT-SoVITS returns a WAV container for every text unit. The live endpoint
    concatenates those units into one browser stream, so only the first unit
    may contribute its RIFF header. This helper also tolerates headers split
    across arbitrary HTTP chunks.
    """
    header_buffer = b""
    data_started = False
    saw_audio = False
    for chunk in chunks:
        if not chunk:
            continue
        if data_started:
            saw_audio = True
            yield chunk
            continue
        header_buffer += chunk
        data_offset = _wav_data_offset(header_buffer)
        if data_offset is None:
            continue
        if include_header:
            yield header_buffer[:data_offset]
        payload = header_buffer[data_offset:]
        if payload:
            saw_audio = True
            yield payload
        data_started = True
    if not data_started:
        raise RuntimeError("GPT-SoVITS 未返回完整 WAV 音频")
    if not saw_audio:
        raise RuntimeError("GPT-SoVITS 未返回 PCM 音频数据")


def _tts_endpoint():
    if not settings.gpt_sovits_url:
        raise HTTPException(503, "GPT-SoVITS 未配置")
    base = settings.gpt_sovits_url.rstrip("/")
    return base if base.endswith("/tts") else base + "/tts"


def _ensure_tts_ready():
    if not _tts_has_reference():
        raise HTTPException(503, "GPT-SoVITS 尚未配置可用参考音频")
    if not _gpt_sovits_reachable():
        raise HTTPException(503, "GPT-SoVITS 服务未启动或不可访问")


INSUFFICIENT_ANSWER = "知识库中暂时没有足够依据回答这个问题。"

# Keep question aliases separate from source labels. Broad aliases such as
# “功率” previously matched the wrong line (150kW instead of 204Ps), while
# many configuration fields were not covered at all.
FIELD_SPECS = [
    {"name": "对外放电功率", "aliases": ("对外放电功率", "外放电功率"), "source": ("对外交流放电功率",), "unit": "kW"},
    {"name": "快充电量范围", "aliases": ("快充电量范围",), "source": ("电池快充电量范围",), "unit": "%"},
    {"name": "电能当量燃料消耗", "aliases": ("电能当量燃料消耗", "电能当量油耗"), "source": ("电能当量燃料消耗量",), "unit": "L/100km"},
    {"name": "前电机型号", "aliases": ("前电机型号", "前电动机型号"), "source": ("前电动机型号",), "unit": ""},
    {"name": "前电机品牌", "aliases": ("前电机品牌", "前电动机品牌"), "source": ("前电动机品牌",), "unit": ""},
    {"name": "慢充接口位置", "aliases": ("慢充接口位置",), "source": ("慢充接口位置",), "unit": ""},
    {"name": "单电机布局", "aliases": ("单电机布局", "电机布局"), "source": ("电机布局",), "unit": ""},
    {"name": "电池冷却方式", "aliases": ("电池冷却方式",), "source": ("电池冷却方式",), "unit": ""},
    {"name": "充电功能", "aliases": ("充电功能", "快充功能"), "source": ("快充功能",), "unit": ""},
    {"name": "车门开启方式", "aliases": ("车门开启方式",), "source": ("车门开启方式",), "unit": ""},
    {"name": "后排侧气囊", "aliases": ("后排侧气囊", "侧气囊"), "source": ("前/后排侧气囊",), "unit": ""},
    {"name": "车道偏离预警", "aliases": ("车道偏离预警",), "source": ("车道偏离预警系统",), "unit": ""},
    {"name": "导航系统", "aliases": ("导航系统", "卫星导航"), "source": ("卫星导航系统",), "unit": ""},
    {"name": "蓝牙车载电话", "aliases": ("蓝牙车载电话", "蓝牙电话", "车载电话"), "source": ("蓝牙/车载电话",), "unit": ""},
    {"name": "自动泊车", "aliases": ("自动泊车", "辅助泊车"), "source": ("辅助泊车入位", "遥控泊车"), "unit": ""},
    {"name": "语音连续识别", "aliases": ("语音连续识别",), "source": ("语音连续识别",), "unit": ""},
    {"name": "辅助驾驶灯", "aliases": ("辅助驾驶灯",), "source": ("辅助驾驶灯",), "unit": ""},
    {"name": "能量回收系统", "aliases": ("能量回收系统",), "source": ("能量回收系统",), "unit": ""},
    {"name": "全液晶仪表盘", "aliases": ("全液晶仪表盘",), "source": ("全液晶仪表盘",), "unit": ""},
    {"name": "多功能方向盘", "aliases": ("多功能方向盘",), "source": ("多功能方向盘",), "unit": ""},
    {"name": "OTA升级", "aliases": ("OTA升级", "OTA"), "source": ("OTA升级",), "unit": ""},
    {"name": "Wi-Fi热点", "aliases": ("Wi-Fi热点", "wifi热点", "热点"), "source": ("Wi-Fi热点",), "unit": ""},
    {"name": "驾驶模式", "aliases": ("驾驶模式",), "source": ("驾驶模式",), "unit": "", "pattern": r"驾驶模式[^。；;]*?(经济、标准、运动)"},
    {"name": "快充时间", "aliases": ("快充时间",), "source": ("电池快充时间",), "unit": "小时"},
    {"name": "慢充时间", "aliases": ("慢充时间",), "source": ("电池慢充时间",), "unit": "小时"},
    {"name": "电动机功率", "aliases": ("电动机功率", "电动机马力"), "source": ("电动机(Ps)", "电动机总马力"), "unit": "Ps"},
    {"name": "最大功率", "aliases": ("最大功率", "总功率"), "source": ("最大功率", "电动机总功率", "前电动机最大功率"), "unit": "kW"},
    {"name": "最大扭矩", "aliases": ("最大扭矩", "总扭矩"), "source": ("最大扭矩", "电动机总扭矩"), "unit": "N·m"},
    {"name": "厂商指导价", "aliases": ("厂商指导价", "指导价", "价格", "售价", "多少钱"), "source": ("厂商指导价",), "unit": "万元"},
    {"name": "电池容量", "aliases": ("电池容量", "电池能量"), "source": ("电池能量",), "unit": "kWh"},
    {"name": "后备厢", "aliases": ("后备厢容积", "后备箱容积", "后备厢", "后备箱"), "source": ("后备厢容积",), "unit": "L"},
    {"name": "续航", "aliases": ("CLTC纯电续航", "纯电续航", "续航"), "source": ("CLTC纯电续航里程",), "unit": "公里"},
    {"name": "轴距", "aliases": ("轴距",), "source": ("轴距",), "unit": "毫米"},
    {"name": "最高车速", "aliases": ("最高车速", "最高速度"), "source": ("最高车速",), "unit": "km/h"},
    {"name": "整备质量", "aliases": ("整备质量",), "source": ("整备质量",), "unit": "kg"},
    {"name": "最大满载质量", "aliases": ("最大满载质量", "满载质量"), "source": ("最大满载质量",), "unit": "kg"},
    {"name": "车身长度", "aliases": ("车身长度", "车长", "长度"), "source": ("长度",), "unit": "mm"},
    {"name": "车身宽度", "aliases": ("车身宽度", "车宽", "宽度"), "source": ("宽度",), "unit": "mm"},
    {"name": "车身高度", "aliases": ("车身高度", "车高", "高度"), "source": ("高度",), "unit": "mm"},
    {"name": "前轮距", "aliases": ("前轮距",), "source": ("前轮距",), "unit": "mm"},
    {"name": "后轮距", "aliases": ("后轮距",), "source": ("后轮距",), "unit": "mm"},
]


def _pick_source(sources, keywords):
    for source in sources:
        content = source.get("content", "")
        if any(keyword in content for keyword in keywords):
            return source
    return sources[0] if sources else None


def _extract_line(text, keywords):
    matches = []
    for raw in re.split(r"[\n\r]+", text):
        line = raw.strip()
        if not line:
            continue
        if any(keyword in line for keyword in keywords):
            value_match = re.search(r"[:：]\s*([^\n\r。；;]+)", line)
            value = value_match.group(1).strip() if value_match else ""
            # Prefer a complete numeric value over a chunk-truncated prefix.
            numeric_score = len(re.findall(r"\d", value))
            exact_score = max((len(keyword) for keyword in keywords if keyword in line), default=0)
            matches.append((numeric_score, exact_score, len(value), line))
    return max(matches, default=(0, 0, 0, ""))[-1]


def _field_spec(question):
    normalized = re.sub(r"[\s_?？：:，,。]+", "", question).lower()
    return next(
        (spec for spec in sorted(FIELD_SPECS, key=lambda item: max(map(len, item["aliases"])), reverse=True)
         if any(alias.lower() in normalized for alias in spec["aliases"])),
        None,
    )


def _field_value(text, spec):
    candidates = []
    for raw in re.split(r"[\n\r]+", text):
        line = raw.strip()
        if not line:
            continue
        pattern = spec.get("pattern")
        if pattern:
            match = re.search(pattern, line)
            if match:
                candidates.append((len(match.group(0)), 0, len(match.group(1)), match.group(1)))
        for keyword in sorted(spec["source"], key=len, reverse=True):
            if keyword not in line:
                continue
            value_match = re.search(r"[:：]\s*([^\n\r。；;]+)", line[line.find(keyword) + len(keyword):])
            if not value_match:
                continue
            value = value_match.group(1).strip().rstrip("，,、")
            if value:
                candidates.append((len(keyword), len(re.findall(r"\d", value)), len(value), value))
            break
    return max(candidates, default=(0, 0, 0, ""))[-1]


def _short_answer(question, sources):
    spec = _field_spec(question)
    if not spec or not sources:
        return INSUFFICIENT_ANSWER
    combined = "\n".join(s.get("content", "") for s in sources)
    value = _field_value(combined, spec)
    if not value:
        return INSUFFICIENT_ANSWER
    unit = spec["unit"]
    suffix = "" if not unit or unit in value or (unit == "万元" and "万" in value) else unit
    return f"{spec['name']}：{value}{suffix}"


def _llm_endpoint():
    base = (settings.llm_base_url or "").rstrip("/")
    if not base:
        return ""
    return base if base.endswith("/chat/completions") else base + "/chat/completions"


def _llm_answer(question, sources):
    """Use an optional OpenAI-compatible model while keeping local RAG fallback.

    Only retrieved evidence is placed in the prompt. If the endpoint is absent,
    unreachable, or returns malformed data, callers continue with the local
    extractive answer instead of turning a knowledge-base query into a 5xx.
    """
    endpoint = _llm_endpoint()
    if not endpoint or not settings.llm_model or not sources:
        return None
    evidence = "\n\n".join(
        f"[{index + 1}] {item.get('content', '')[:1200]}"
        for index, item in enumerate(sources[:5])
    )
    payload = {
        "model": settings.llm_model,
        "temperature": 0.2,
        "messages": [
            {
                "role": "system",
                "content": "你是汽车销售直播问答助手。只能依据给定资料回答，不得补充资料中没有的参数、价格或政策；无法确认时明确说资料不足。回答简洁、适合直播口播。",
            },
            {"role": "user", "content": f"问题：{question}\n\n资料：\n{evidence}"},
        ],
    }
    headers = {"Content-Type": "application/json"}
    if settings.llm_api_key:
        headers["Authorization"] = f"Bearer {settings.llm_api_key}"
    try:
        with httpx.Client(timeout=30, trust_env=False) as client:
            response = client.post(endpoint, json=payload, headers=headers)
            response.raise_for_status()
            body = response.json()
        content = body.get("choices", [{}])[0].get("message", {}).get("content", "")
        content = re.sub(r"\s+", " ", str(content)).strip()
        return content[:1200] or None
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError):
        return None


@app.post("/api/tts/synthesize")
def synthesize_tts(req: TTSRequest):
    _ensure_tts_ready()
    try:
        with TTS_LOCK:
            with httpx.Client(timeout=120, trust_env=False) as client:
                _ensure_model_profile_loaded(_voice_model_profile(req.voice_id), client)
                response = client.post(_tts_endpoint(), json=_tts_params(req))
                response.raise_for_status()
                _mark_tts_success()
    except httpx.HTTPError as exc:
        raise HTTPException(502, f"GPT-SoVITS 服务调用失败：{exc}") from exc
    return Response(content=response.content, media_type=response.headers.get("content-type", "audio/wav"))


@app.post("/api/tts/stream")
async def stream_tts(req: TTSRequest, request: Request):
    """Pass GPT-SoVITS PCM fragments through without buffering the whole utterance."""
    _ensure_tts_ready()
    endpoint = _tts_endpoint()
    units = _tts_stream_units(req)

    async def iterator():
        try:
            timeout = httpx.Timeout(120, connect=10, read=30, write=10, pool=10)
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                sent_wav_header = False
                for unit_index, unit in enumerate(units):
                    # Keep the single-worker lock only for this short phrase.
                    # If a browser cancels a revision, the next phrase can
                    # continue as soon as the current upstream request closes.
                    acquired = await asyncio.to_thread(TTS_LOCK.acquire, True, 20)
                    if not acquired:
                        raise RuntimeError("语音引擎正在处理上一条请求，请稍后重试")
                    try:
                        await _ensure_model_profile_loaded_async(_voice_model_profile(req.voice_id), client)
                        params = _live_unit_params(req.model_copy(update={"text": unit}), unit_index)
                        async with client.stream("POST", endpoint, json=params) as response:
                            response.raise_for_status()
                            _mark_tts_success()
                            header_buffer = b""
                            data_started = False
                            async for chunk in response.aiter_raw(8192):
                                if await request.is_disconnected():
                                    return
                                if data_started:
                                    yield chunk
                                    continue
                                header_buffer += chunk
                                data_offset = _wav_data_offset(header_buffer)
                                if data_offset is None:
                                    continue
                                if not sent_wav_header:
                                    yield header_buffer[:data_offset]
                                    sent_wav_header = True
                                payload = header_buffer[data_offset:]
                                if payload:
                                    yield payload
                                data_started = True
                    finally:
                        TTS_LOCK.release()
        except (GeneratorExit, asyncio.CancelledError):
            # The UI aborts this request when a host edits the live script. Closing
            # the upstream response here frees the inference worker immediately.
            return
        except httpx.HTTPError as exc:
            raise RuntimeError(f"GPT-SoVITS 流式调用失败：{exc}") from exc

    return StreamingResponse(
        iterator(),
        media_type="audio/wav",
        headers={
            "Cache-Control": "no-store",
            "X-Accel-Buffering": "no",
            "X-TTS-Mode": "gpt-sovits-pcm-stream",
        },
    )


@app.get("/api/dashboard")
def dashboard():
    with conn() as c:
        docs = c.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        chunks = c.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        versions = c.execute("SELECT COUNT(*) FROM document_versions").fetchone()[0]
        vehicles = [dict(x) for x in c.execute("SELECT DISTINCT brand,series,year FROM documents WHERE brand<>'' ORDER BY brand,series,year").fetchall()]
    return {"documents": docs, "chunks": chunks, "versions": versions, "vehicles": vehicles, "retrieval_target": 85}


@app.get("/api/documents")
def documents():
    with conn() as c:
        return [dict(x) for x in c.execute("SELECT * FROM documents ORDER BY id DESC").fetchall()]


@app.get("/api/documents/{did}/versions")
def document_versions(did: int):
    with conn() as c:
        return [dict(x) for x in c.execute("SELECT * FROM document_versions WHERE document_id=? ORDER BY version DESC", (did,)).fetchall()]


async def _save_upload(file: UploadFile, folder: Path, allowed: set[str], max_bytes: int, label: str):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(400, f"{label}格式不受支持")
    content_length = file.headers.get("content-length") if file.headers else None
    if content_length and content_length.isdigit() and int(content_length) > max_bytes:
        raise HTTPException(413, f"{label}不能超过 {max_bytes // (1024 * 1024)} MB")
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{uuid4().hex}{suffix}"
    total = 0
    try:
        with path.open("wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise HTTPException(413, f"{label}不能超过 {max_bytes // (1024 * 1024)} MB")
                out.write(chunk)
        return path
    except Exception:
        path.unlink(missing_ok=True)
        raise
    finally:
        await file.close()


def _unlink_owned_upload(path_value):
    """Remove only files created under the managed upload directory."""
    if not path_value:
        return False
    try:
        path = Path(path_value).resolve()
        upload_root = settings.upload_dir.resolve()
        if path == upload_root or not path.is_relative_to(upload_root):
            return False
        path.unlink(missing_ok=True)
        return True
    except (OSError, RuntimeError):
        return False


@app.post("/api/documents")
async def upload(file: UploadFile = File(...), brand: str = Form(""), series: str = Form(""), year: str = Form("")):
    path = await _save_upload(file, settings.upload_dir, ALLOWED_DOCS, settings.max_document_bytes, "资料")
    try:
        return {"id": ingest(path, file.filename or path.name, brand, series, year), "status": "ready"}
    except ValueError as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(422, str(exc)) from exc
    except Exception:
        path.unlink(missing_ok=True)
        raise


@app.post("/api/documents/batch")
async def upload_batch(files: List[UploadFile] = File(...), brand: str = Form(""), series: str = Form(""), year: str = Form("")):
    results = []
    for file in files:
        path = None
        try:
            path = await _save_upload(file, settings.upload_dir, ALLOWED_DOCS, settings.max_document_bytes, "资料")
            results.append({"id": ingest(path, file.filename or path.name, brand, series, year), "name": file.filename, "status": "ready"})
        except ValueError as exc:
            path and path.unlink(missing_ok=True)
            results.append({"name": file.filename, "status": "error", "error": str(exc)})
        except HTTPException as exc:
            path and path.unlink(missing_ok=True)
            results.append({"name": file.filename, "status": "error", "error": str(exc.detail)})
        except Exception as exc:
            path and path.unlink(missing_ok=True)
            results.append({"name": file.filename, "status": "error", "error": f"导入失败：{exc}"})
    ready = sum(item["status"] == "ready" for item in results)
    if not ready and results:
        raise HTTPException(422, results[0].get("error", "没有文件导入成功"))
    return {"count": ready, "items": results}


@app.put("/api/documents/{did}")
async def update_document(did: int, file: UploadFile = File(...), brand: str = Form(""), series: str = Form(""), year: str = Form("")):
    path = await _save_upload(file, settings.upload_dir, ALLOWED_DOCS, settings.max_document_bytes, "资料")
    try:
        return {"id": replace_document(did, path, file.filename or path.name, brand, series, year), "status": "updated"}
    except ValueError as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(422, str(exc)) from exc
    except Exception:
        path.unlink(missing_ok=True)
        raise


@app.delete("/api/documents/{did}")
def delete(did: int):
    with conn() as c:
        rows = c.execute("SELECT path FROM document_versions WHERE document_id=? UNION SELECT path FROM documents WHERE id=?", (did, did)).fetchall()
        if not c.execute("SELECT 1 FROM documents WHERE id=?", (did,)).fetchone():
            raise HTTPException(404, "资料不存在")
        c.execute("DELETE FROM documents WHERE id=?", (did,))
    for row in rows:
        _unlink_owned_upload(row["path"])
    return {"deleted": did}


@app.post("/api/query")
def query(q: Query):
    start = time.perf_counter()
    sources = retrieve(q.question, q.brand, q.series, q.year, q.top_k)
    local_answer = _short_answer(q.question, sources)
    answerable = bool(sources and local_answer != INSUFFICIENT_ANSWER)
    if answerable:
        answer = "根据当前车型资料：" + local_answer
        confidence = "high" if sources[0]["score"] > 0.35 else "medium"
    else:
        answer = INSUFFICIENT_ANSWER
        confidence = "low"
    llm_answer = _llm_answer(q.question, sources) if sources else None
    if llm_answer:
        answer = llm_answer
        confidence = "high" if sources[0]["score"] > 0.25 else "medium"
        provider = "llm-grounded-rag"
    else:
        provider = "local-extractive"
    return {"answer": answer, "confidence": confidence, "provider": provider, "latency_ms": int((time.perf_counter() - start) * 1000), "sources": sources}


@app.post("/api/script/generate")
def generate_script(req: ScriptRequest):
    sources = retrieve(req.selling_points, req.brand, req.series, req.year, 3)
    facts = "".join(s["content"][:180] for s in sources)
    script = f"大家好，今天介绍{req.brand}{req.series}。它的核心卖点是：{req.selling_points}。根据资料，{facts}欢迎大家在评论区继续提问。"
    return {"script": script, "sources": sources}


@app.get("/api/voices")
def voices():
    with conn() as c:
        # Put uploaded/cloned voices first so the live studio uses the user's voice by default.
        rows = [dict(x) for x in c.execute(
            "SELECT id,name,style,provider,prompt_text,prompt_lang,model_profile,aux_reference_paths,"
            "sampling_seed,sampling_top_p,sampling_temperature,sampling_model_version,calibration_details,created_at,"
            "CASE WHEN reference_path<>'' THEN 1 ELSE 0 END AS cloned FROM voices"
        ).fetchall()]
        paths = {row["id"]: row["reference_path"] for row in c.execute("SELECT id,reference_path FROM voices").fetchall()}
    for row in rows:
        row["quality"] = _audio_quality(paths.get(row["id"], "")) if row["cloned"] else {"status": "system", "message": "系统音色"}
        try:
            aux_paths = json.loads(row.get("aux_reference_paths") or "[]")
        except (TypeError, ValueError):
            aux_paths = []
        raw_reference_count = 1 + sum(Path(path).is_file() for path in aux_paths if isinstance(path, str)) if row["cloned"] else 0
        effective_aux_paths = _voice_aux_reference_paths(row["id"]) if row["cloned"] else []
        row["reference_count"] = 1 + len(effective_aux_paths) if row["cloned"] else 0
        row["uploaded_reference_count"] = raw_reference_count
        row.pop("aux_reference_paths", None)
        if row["cloned"] and not (row.get("prompt_text") or "").strip():
            row["quality"]["status"] = "needs-review"
            row["quality"]["message"] = "参考文本未填写；" + row["quality"].get("message", "请补充与录音完全一致的文本")
        row["prompt_advice"] = _prompt_alignment(row.get("prompt_text", ""), row["quality"].get("duration")) if row["cloned"] else {"status": "system", "message": "系统音色"}
        row["warmed"] = row["id"] in VOICE_WARMED
        row["calibrating"] = row["id"] in VOICE_CALIBRATING
        try:
            calibration_details = json.loads(row.get("calibration_details") or "{}")
        except (TypeError, ValueError):
            calibration_details = {}
        row["sampling_calibrated"] = all(
            row.get(key) is not None for key in ("sampling_seed", "sampling_top_p", "sampling_temperature")
        ) and row.get("sampling_model_version") == settings.gpt_sovits_model_version \
            and calibration_details.get("calibration_version") == CALIBRATION_VERSION
        row["sampling_profile"] = {
            "top_p": round(float(row.get("sampling_top_p") or DEFAULT_SAMPLING_PROFILE["top_p"]), 2),
            "temperature": round(float(row.get("sampling_temperature") or DEFAULT_SAMPLING_PROFILE["temperature"]), 2),
            "repetition_penalty": DEFAULT_SAMPLING_PROFILE["repetition_penalty"],
            "calibrated": row["sampling_calibrated"],
        }
        reference_risk = calibration_details.get("reference_prosody_risk") or {}
        if reference_risk.get("level") == "high":
            row["prosody_advice"] = "参考录音语气起伏较强，已自动采用更稳定的合成参数"
        elif row["sampling_calibrated"]:
            row["prosody_advice"] = "已联合校准音色相似度与语气稳定性"
        else:
            row["prosody_advice"] = "正在分析音色与语气"
        row["warming"] = row["id"] in VOICE_WARMING
        row.pop("sampling_seed", None)
        row.pop("sampling_top_p", None)
        row.pop("sampling_temperature", None)
        row.pop("sampling_model_version", None)
        row.pop("calibration_details", None)
        row["profile"] = VOICE_STYLE_PROFILES.get(row["id"], {})
    # A stale clone with missing text or a damaged reference must never become
    # the default just because it was uploaded earlier than a usable clone.
    # Keep system voices last, then put validated clones ahead of review items.
    rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    rows.sort(
        key=lambda row: (
            0 if row["cloned"] and row["quality"].get("status") == "ready" else
            1 if row["cloned"] else 2
        ),
    )
    return rows


@app.post("/api/voices/analyze")
async def analyze_voice(sample: UploadFile = File(...), aux_samples: List[UploadFile] = File(default=[]), prompt_text: str = Form("")):
    """Run the same fast quality gate used by cloning without saving a voice."""
    suffix = Path(sample.filename or "").suffix.lower()
    if suffix not in ALLOWED_AUDIO:
        raise HTTPException(400, "音色样本仅支持 WAV、MP3、FLAC、OGG、M4A")
    if len(aux_samples) > MAX_AUX_REFERENCE_AUDIO:
        raise HTTPException(422, f"最多添加 {MAX_AUX_REFERENCE_AUDIO} 条辅助参考音频")
    prompt_text = _normalize_prompt_text(prompt_text)
    folder = settings.upload_dir / "voice-staging"
    path = await _save_upload(sample, folder, ALLOWED_AUDIO, settings.max_audio_bytes, "音色样本")
    generated = None
    aux_paths = []
    try:
        if path.stat().st_size < 16 * 1024:
            raise HTTPException(422, "参考音频过短或无有效音频数据，请上传清晰、单人录制的 3 到 10 秒样本")
        generated = _normalize_reference_audio(path, force=True)
        quality = _audio_quality(str(generated))
        for aux_sample in aux_samples[:MAX_AUX_REFERENCE_AUDIO]:
            aux_suffix = Path(aux_sample.filename or "").suffix.lower()
            if aux_suffix not in ALLOWED_AUDIO:
                raise HTTPException(400, "辅助参考音频仅支持 WAV、MP3、FLAC、OGG、M4A")
            aux_source = await _save_upload(aux_sample, folder, ALLOWED_AUDIO, settings.max_audio_bytes, "辅助参考音频")
            aux_paths.append(aux_source)
            if aux_source.stat().st_size < 16 * 1024:
                aux_source.unlink(missing_ok=True)
                raise HTTPException(422, "每条辅助参考音频都需要 3 到 10 秒的清晰人声")
            aux_normalized = _normalize_reference_audio(aux_source, force=True)
            aux_quality = _audio_quality(str(aux_normalized))
            if aux_quality["status"] != "ready":
                raise HTTPException(422, f"辅助参考音频不适合快速克隆：{aux_quality['message']}")
            aux_paths.append(aux_normalized)
        return {
            "status": "ready" if quality["status"] == "ready" else "needs-review",
            "quality": quality,
            "prompt_advice": _prompt_alignment(prompt_text, quality.get("duration")),
            "auxiliary": {
                "count": len(aux_paths) // 2,
                "message": "辅助参考会用于同一说话人的音色融合" if aux_paths else "可添加 1-2 条同一说话人的不同句子以提高音色稳定性",
            },
            "recommendation": "可以创建克隆音色" if quality["status"] == "ready" else "建议更换或优化参考音频后再创建",
        }
    finally:
        path.unlink(missing_ok=True)
        if generated and generated != path:
            generated.unlink(missing_ok=True)
        for item in aux_paths:
            if item != path and item != generated:
                item.unlink(missing_ok=True)


@app.post("/api/voices/clone")
async def clone_voice(sample: UploadFile = File(...), aux_samples: List[UploadFile] = File(default=[]), name: str = Form("自定义主播"), style: str = Form("克隆"), prompt_text: str = Form(""), prompt_lang: str = Form("zh")):
    suffix = Path(sample.filename or "").suffix.lower()
    if suffix not in ALLOWED_AUDIO:
        raise HTTPException(400, "音色样本仅支持 WAV、MP3、FLAC、OGG、M4A")
    prompt_text = _normalize_prompt_text(prompt_text)
    prompt_core = re.sub(r"[\s\W_]+", "", prompt_text, flags=re.UNICODE)
    if len(prompt_core) < 4:
        raise HTTPException(422, "为保证音色、发音和韵律，请填写至少 4 个字且与参考音频逐字一致的原文")
    if len(prompt_text) > 500:
        raise HTTPException(422, "参考音频原文不能超过 500 个字符")
    if len(aux_samples) > MAX_AUX_REFERENCE_AUDIO:
        raise HTTPException(422, f"最多添加 {MAX_AUX_REFERENCE_AUDIO} 条辅助参考音频")
    folder = settings.upload_dir / "voices"
    folder.mkdir(parents=True, exist_ok=True)
    path = await _save_upload(sample, folder, ALLOWED_AUDIO, settings.max_audio_bytes, "音色样本")
    aux_sources = []
    aux_normalized = []
    if path.stat().st_size < 16 * 1024:
        path.unlink(missing_ok=True)
        raise HTTPException(422, "参考音频过短或无有效音频数据，请上传清晰、单人录制的 3 到 10 秒样本")
    try:
        reference_path = _normalize_reference_audio(path, force=True)
        for aux_sample in aux_samples:
            aux_suffix = Path(aux_sample.filename or "").suffix.lower()
            if aux_suffix not in ALLOWED_AUDIO:
                raise HTTPException(400, "辅助参考音频仅支持 WAV、MP3、FLAC、OGG、M4A")
            aux_source = await _save_upload(aux_sample, folder, ALLOWED_AUDIO, settings.max_audio_bytes, "辅助参考音频")
            aux_sources.append(aux_source)
            if aux_source.stat().st_size < 16 * 1024:
                raise HTTPException(422, "每条辅助参考音频都需要 3 到 10 秒的清晰人声")
            aux_normalized.append(_normalize_reference_audio(aux_source, force=True))
    except Exception:
        path.unlink(missing_ok=True)
        for item in aux_sources + aux_normalized:
            item.unlink(missing_ok=True)
        raise
    vid = "voice-" + uuid4().hex[:12]
    quality = _audio_quality(str(reference_path))
    if quality["status"] == "invalid":
        path.unlink(missing_ok=True)
        if reference_path != path:
            reference_path.unlink(missing_ok=True)
        for item in aux_sources + aux_normalized:
            item.unlink(missing_ok=True)
        raise HTTPException(422, "参考音频预处理后无有效 PCM 音频，请重新录制清晰的人声样本")
    if quality["status"] == "needs-review":
        path.unlink(missing_ok=True)
        if reference_path != path:
            reference_path.unlink(missing_ok=True)
        for item in aux_sources + aux_normalized:
            item.unlink(missing_ok=True)
        raise HTTPException(422, f"参考音频暂不适合快速克隆：{quality['message']}。请先更换干净样本")
    aux_quality = []
    for aux_path in aux_normalized:
        item_quality = _audio_quality(str(aux_path))
        if item_quality["status"] != "ready":
            path.unlink(missing_ok=True)
            if reference_path != path:
                reference_path.unlink(missing_ok=True)
            for item in aux_sources + aux_normalized:
                item.unlink(missing_ok=True)
            raise HTTPException(422, f"辅助参考音频暂不适合快速克隆：{item_quality['message']}")
        aux_quality.append(item_quality)
    prompt_advice = _prompt_alignment(prompt_text, quality.get("duration"))
    try:
        with conn() as c:
            c.execute("INSERT INTO voices(id,name,style,provider,reference_path,prompt_text,prompt_lang,aux_reference_paths,model_profile,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (vid, name, style, "gpt-sovits", str(reference_path), prompt_text, prompt_lang, json.dumps([str(item) for item in aux_normalized], ensure_ascii=False), "base", now()))
    except Exception:
        path.unlink(missing_ok=True)
        if reference_path != path:
            reference_path.unlink(missing_ok=True)
        for item in aux_sources + aux_normalized:
            item.unlink(missing_ok=True)
        raise
    threading.Thread(target=_warm_single_voice, args=(vid,), name=f"warm-voice-{vid}", daemon=True).start()
    return {
        "id": vid,
        "name": name,
        "status": "ready",
        "reference_audio": reference_path.name,
        "reference_count": 1 + len(aux_normalized),
        "auxiliary_quality": aux_quality,
        "warming": True,
        "warmed": False,
        "quality": quality,
        "prompt_advice": prompt_advice,
        "quality_hint": "样本已通过质量检查，正在预热克隆音色；参考文本必须与主参考录音逐字一致，额外参考音频仅用于增强音色稳定性",
    }


@app.post("/api/voices/{voice_id}/optimize")
def optimize_voice(voice_id: str):
    with conn() as c:
        row = c.execute("SELECT id,reference_path,prompt_text,aux_reference_paths FROM voices WHERE id=?", (voice_id,)).fetchone()
    if not row or not row["reference_path"]:
        raise HTTPException(404, "克隆音色或参考音频不存在")
    source_prompt = row["prompt_text"] or ""
    if len(re.sub(r"[\s\W_]+", "", source_prompt, flags=re.UNICODE)) < 4:
        raise HTTPException(422, "请先填写至少 4 个字且与参考录音逐字一致的参考文本")
    source_path = _original_reference_audio(Path(row["reference_path"]))
    reference_path = _normalize_reference_audio(source_path, force=True)
    try:
        aux_sources = json.loads(row["aux_reference_paths"] or "[]")
    except (TypeError, ValueError):
        aux_sources = []
    optimized_aux = []
    for aux_source in aux_sources[:MAX_AUX_REFERENCE_AUDIO]:
        if not isinstance(aux_source, str) or not Path(aux_source).is_file():
            continue
        optimized_aux.append(str(_normalize_reference_audio(_original_reference_audio(Path(aux_source)), force=True)))
    prompt_text = _normalize_prompt_text(source_prompt)
    with conn() as c:
        c.execute(
            "UPDATE voices SET reference_path=?,prompt_text=?,aux_reference_paths=?,"
            "validated_aux_reference_paths=NULL,sampling_seed=NULL,sampling_top_p=NULL,"
            "sampling_temperature=NULL,sampling_model_version=NULL,calibration_details=NULL WHERE id=?",
            (str(reference_path), prompt_text, json.dumps(optimized_aux, ensure_ascii=False), voice_id),
        )
    VOICE_WARMED.discard(voice_id)
    threading.Thread(target=_warm_single_voice, args=(voice_id,), name=f"warm-voice-{voice_id}", daemon=True).start()
    quality = _audio_quality(str(reference_path))
    return {"id": voice_id, "reference_audio": reference_path.name, "reference_count": 1 + len(optimized_aux), "quality": quality, "prompt_advice": _prompt_alignment(prompt_text, quality.get("duration")), "warming": True, "warmed": False, "status": "ready"}


@app.delete("/api/voices/{voice_id}")
def delete_voice(voice_id: str):
    with conn() as c:
        row = c.execute("SELECT reference_path,aux_reference_paths,provider FROM voices WHERE id=?", (voice_id,)).fetchone()
        if not row or not row["reference_path"]:
            raise HTTPException(404, "音色不存在或系统预置音色不可删除")
        c.execute("DELETE FROM voices WHERE id=?", (voice_id,))
    if row["reference_path"]:
        _unlink_owned_upload(row["reference_path"])
    try:
        aux_paths = json.loads(row["aux_reference_paths"] or "[]")
    except (TypeError, ValueError):
        aux_paths = []
    for path in aux_paths:
        _unlink_owned_upload(path)
    VOICE_WARMED.discard(voice_id)
    VOICE_WARMING.discard(voice_id)
    VOICE_CALIBRATING.discard(voice_id)
    return {"deleted": voice_id}


@app.patch("/api/voices/{voice_id}")
def update_voice(voice_id: str, update: VoiceUpdate):
    changes = update.model_dump(exclude_none=True)
    if not changes:
        raise HTTPException(400, "没有需要更新的内容")
    allowed = {"name", "style", "prompt_text", "prompt_lang"}
    changes = {key: value for key, value in changes.items() if key in allowed}
    prompt_changed = False
    with conn() as c:
        row = c.execute("SELECT id,reference_path,prompt_text FROM voices WHERE id=?", (voice_id,)).fetchone()
        if not row:
            raise HTTPException(404, "音色不存在")
        if not row["reference_path"]:
            raise HTTPException(400, "系统预置音色不可修改")
        if "prompt_text" in changes:
            changes["prompt_text"] = _normalize_prompt_text(changes["prompt_text"])
            if row["reference_path"] and len(re.sub(r"[\s\W_]+", "", changes["prompt_text"], flags=re.UNICODE)) < 4:
                raise HTTPException(422, "克隆音色必须保留至少 4 个字且与参考音频逐字一致的原文")
            prompt_changed = changes["prompt_text"] != _normalize_prompt_text(row["prompt_text"] or "")
        assignments = ", ".join(f"{key}=?" for key in changes)
        c.execute(f"UPDATE voices SET {assignments} WHERE id=?", (*changes.values(), voice_id))
        if prompt_changed:
            c.execute(
                "UPDATE voices SET sampling_seed=NULL,sampling_top_p=NULL,sampling_temperature=NULL,"
                "sampling_model_version=NULL,calibration_details=NULL WHERE id=?",
                (voice_id,),
            )
        saved = c.execute("SELECT id,name,style,prompt_text,prompt_lang FROM voices WHERE id=?", (voice_id,)).fetchone()
    result = dict(saved)
    if prompt_changed:
        VOICE_WARMED.discard(voice_id)
        threading.Thread(target=_warm_single_voice, args=(voice_id,), name=f"warm-voice-{voice_id}", daemon=True).start()
        result.update({"warming": True, "warmed": False})
    return result


@app.post("/api/live/sessions")
def create_session(s: Session):
    sid = uuid4().hex
    with conn() as c:
        c.execute("INSERT INTO sessions(id,vehicle,script,version,sentence,status,updated_at,voice_id) VALUES(?,?,?,?,?,?,?,?)", (sid, s.vehicle, s.script, 1, 0, "idle", now(), s.voice_id))
    return session(sid)


def session(sid):
    with conn() as c:
        row = c.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
    if not row:
        raise HTTPException(404, "直播会话不存在")
    return dict(row)


@app.get("/api/live/sessions/{sid}")
def get_session(sid):
    return session(sid)


@app.patch("/api/live/sessions/{sid}/script")
def revise(sid: str, r: Revision):
    with conn() as c:
        row = c.execute("SELECT version FROM sessions WHERE id=?", (sid,)).fetchone()
        if not row:
            raise HTTPException(404, "直播会话不存在")
        c.execute("UPDATE sessions SET script=?,version=?,sentence=?,updated_at=? WHERE id=?", (r.script, row["version"] + 1, r.sentence, now(), sid))
    return session(sid)


@app.patch("/api/live/sessions/{sid}/state")
def state(sid: str, s: State):
    with conn() as c:
        c.execute("UPDATE sessions SET status=?,sentence=?,updated_at=? WHERE id=?", (s.status, s.sentence, now(), sid))
    return session(sid)


@app.post("/api/tests/retrieval")
def test_retrieval():
    if not settings.testset_path.is_file():
        raise HTTPException(503, "检索测试集不存在")
    cases = json.loads(settings.testset_path.read_text(encoding="utf-8"))
    passed, failures, lat = 0, [], []
    for item in cases:
        start = time.perf_counter()
        src = retrieve(item["question"], item.get("brand", ""), item.get("series", ""), item.get("year", ""), 5)
        lat.append((time.perf_counter() - start) * 1000)
        text = "\n".join(x["content"] for x in src)
        ok = all(x in text for x in item["expected"])
        passed += ok
        if not ok:
            failures.append(item)
    accuracy = round(passed / len(cases) * 100, 1) if cases else 0
    return {"total": len(cases), "passed": passed, "failed": len(cases) - passed, "accuracy": accuracy, "average_latency_ms": round(sum(lat) / len(lat), 1) if lat else 0, "meets_target": accuracy >= 85 and len(cases) >= 40, "sample_target": len(cases) >= 40, "failures": failures[:10]}


@app.post("/api/tests/qa")
def test_qa():
    """Validate the final local answer, not just whether a source was retrieved."""
    if not settings.testset_path.is_file():
        raise HTTPException(503, "问答测试集不存在")
    cases = json.loads(settings.testset_path.read_text(encoding="utf-8"))
    passed, failures, latencies = 0, [], []
    for item in cases:
        start = time.perf_counter()
        sources = retrieve(item["question"], item.get("brand", ""), item.get("series", ""), item.get("year", ""), 5)
        answer = _short_answer(item["question"], sources)
        latency = round((time.perf_counter() - start) * 1000, 1)
        latencies.append(latency)
        ok = answer != INSUFFICIENT_ANSWER and all(expected in answer for expected in item["expected"])
        passed += ok
        if not ok:
            failures.append({"question": item["question"], "expected": item["expected"], "answer": answer})
    accuracy = round(passed / len(cases) * 100, 1) if cases else 0
    return {
        "total": len(cases),
        "passed": passed,
        "failed": len(cases) - passed,
        "accuracy": accuracy,
        "average_latency_ms": round(sum(latencies) / len(latencies), 1) if latencies else 0,
        "target": 85,
        "sample_target": len(cases) >= 40,
        "meets_target": accuracy >= 85 and len(cases) >= 40,
        "provider": "local-structured-extractive",
        "failures": failures[:10],
    }


@app.post("/api/tests/tts")
def test_tts():
    _ensure_tts_ready()
    if not TTS_WARMUP.is_set() or VOICE_WARMING:
        raise HTTPException(503, "TTS 模型或音色仍在预热，请等待启动脚本提示服务就绪后再验收")
    samples = ["欢迎来到汽车直播间。", "今天为大家介绍这款车型的续航和智能配置。", "如果你想了解购车政策，可以在评论区留言。"]
    latencies = []
    sample_results = []
    voice_id = _preferred_clone_voice_id()
    for text in samples:
        # Measure the first natural live unit. The production stream endpoint
        # splits a long request into the same units before invoking GPT-SoVITS.
        text = _tts_text_units(text)[0]
        start = time.perf_counter()
        try:
            with httpx.Client(timeout=120, trust_env=False) as client:
                # Measure the arrival of the first PCM bytes rather than the full
                # utterance. This is the actual first-playable-audio latency used
                # by the live stream player.
                with TTS_LOCK:
                    with client.stream("POST", _tts_endpoint(), json=_tts_params(TTSRequest(text=text, voice_id=voice_id), streaming=True)) as response:
                        response.raise_for_status()
                        received = 0
                        first_audio_at = None
                        for chunk in response.iter_raw(8192):
                            received += len(chunk)
                            # Keep draining the upstream response after the first PCM
                            # bytes arrive. Closing early leaves GPT-SoVITS inference
                            # running on the GPU and makes the next request stall.
                            if first_audio_at is None and received > 128:
                                first_audio_at = time.perf_counter()
                if first_audio_at is None:
                    raise RuntimeError("未收到可播放音频数据")
            latency = round((first_audio_at - start) * 1000, 1)
            latencies.append(latency)
            sample_results.append({"text": text, "first_audio_ms": latency, "ok": True})
        except Exception as exc:
            latencies.append(None)
            sample_results.append({"text": text, "first_audio_ms": None, "ok": False, "error": str(exc)[:200]})
    valid = [x for x in latencies if x is not None]
    avg = round(sum(valid) / len(valid), 1) if valid else None
    return {
        "samples": len(samples),
        "voice_id": voice_id,
        "sample_results": sample_results,
        "latencies_ms": latencies,
        "first_audio_latencies_ms": latencies,
        "average_ms": avg,
        "average_first_audio_ms": avg,
        "first_audio_target_ms": 3000,
        "meets_target": bool(valid and max(valid) <= 3000),
    }
