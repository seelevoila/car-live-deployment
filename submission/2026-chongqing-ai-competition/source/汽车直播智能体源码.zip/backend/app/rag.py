import hashlib
import math
import re
from .db import conn


def tokens(text):
    text = re.sub(r"\s+", "", text.lower())
    out = re.findall(r"[a-z0-9][a-z0-9_.+-]*", text)
    for run in re.findall(r"[\u4e00-\u9fff]+", text):
        out.extend(run[i : i + 2] for i in range(max(1, len(run) - 1)))
    return out


def split_text(text, size=220, overlap=40):
    text = re.sub(r"\n{2,}", "\n", text).strip()
    parts = [p.strip() for p in re.split(r"(?<=[。！？；.!?;])", text) if p.strip()]
    chunks, current = [], ""
    for part in parts:
        if current and len(current) + len(part) > size:
            chunks.append(current)
            current = current[-overlap:] + part
        else:
            current += part
    if current:
        chunks.append(current)
    return chunks or ([text] if text else [])


def vec(text, dimensions=256):
    """Deterministic sparse hashing vector for offline deployment.

    It keeps the project self-contained while providing a real normalized vector
    representation that can later be replaced by a sentence-transformer model.
    """
    vector = [0.0] * dimensions
    for term in tokens(text):
        digest = hashlib.blake2b(term.encode("utf-8"), digest_size=8).digest()
        bucket = int.from_bytes(digest, "big") % dimensions
        vector[bucket] += 1.0
    norm = math.sqrt(sum(x * x for x in vector)) or 1.0
    return [x / norm for x in vector]


def sim(a, b):
    return sum(x * y for x, y in zip(a, b))


def retrieve(question, brand="", series="", year="", k=5):
    where, args = [], []
    for col, val in [("d.brand", brand), ("d.series", series), ("d.year", year)]:
        if val:
            where.append(col + "=?")
            args.append(val)
    clause = "WHERE " + " AND ".join(where) if where else ""
    with conn() as c:
        rows = c.execute(
            f"SELECT ch.*,d.name,d.brand,d.series,d.year FROM chunks ch JOIN documents d ON d.id=ch.document_id {clause}", args
        ).fetchall()
    q = vec(question)
    query_terms = set(tokens(question))
    scored = []
    for row in rows:
        lexical = len(query_terms.intersection(set(row["tokens"].split())))
        exact_hits = sum(1 for term in query_terms if len(term) >= 2 and term in row["content"])
        score = max(0.0, sim(q, vec(row["content"]))) + lexical * 0.05 + exact_hits * 0.4
        scored.append((score, row))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [
        {
            "document_id": row["document_id"],
            "document_name": row["name"],
            "content": row["content"],
            "page": row["page"],
            "score": round(score, 4),
            "metadata": {"brand": row["brand"], "series": row["series"], "year": row["year"]},
        }
        for score, row in scored[:k]
    ]
