import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from .config import settings


def now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def conn():
    settings.database_path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(settings.database_path, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=10000')
    try:
        yield c
        c.commit()
    finally:
        c.close()


def _add_column(c, table, column, definition):
    columns = {row[1] for row in c.execute(f'PRAGMA table_info({table})').fetchall()}
    if column not in columns:
        c.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')


def init_db():
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    with conn() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('PRAGMA synchronous=NORMAL')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS documents(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, path TEXT, type TEXT,
          size INTEGER, brand TEXT DEFAULT '', series TEXT DEFAULT '', year TEXT DEFAULT '',
          chunks INTEGER DEFAULT 0, version INTEGER DEFAULT 1, created_at TEXT, updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS document_versions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL,
          version INTEGER NOT NULL, name TEXT, path TEXT, size INTEGER,
          chunks INTEGER DEFAULT 0, created_at TEXT,
          FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS chunks(
          id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER, content TEXT,
          tokens TEXT, page INTEGER, FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS sessions(
          id TEXT PRIMARY KEY, vehicle TEXT, script TEXT, version INTEGER DEFAULT 1,
          sentence INTEGER DEFAULT 0, status TEXT DEFAULT 'idle', updated_at TEXT,
          voice_id TEXT DEFAULT 'browser-default'
        );
        CREATE TABLE IF NOT EXISTS voices(
          id TEXT PRIMARY KEY, name TEXT, style TEXT, provider TEXT,
          reference_path TEXT DEFAULT '', prompt_text TEXT DEFAULT '', prompt_lang TEXT DEFAULT 'zh',
          aux_reference_paths TEXT DEFAULT '[]',
          created_at TEXT
        );
        ''')
        for table, column, definition in [
            ('documents', 'version', 'INTEGER DEFAULT 1'),
            ('documents', 'updated_at', 'TEXT'),
            ('voices', 'reference_path', "TEXT DEFAULT ''"),
            ('voices', 'prompt_text', "TEXT DEFAULT ''"),
            ('voices', 'prompt_lang', "TEXT DEFAULT 'zh'"),
            ('voices', 'aux_reference_paths', "TEXT DEFAULT '[]'"),
            ('voices', 'validated_aux_reference_paths', 'TEXT'),
            ('voices', 'sampling_seed', 'INTEGER'),
            ('voices', 'sampling_top_p', 'REAL'),
            ('voices', 'sampling_temperature', 'REAL'),
            ('voices', 'sampling_model_version', 'TEXT'),
            ('voices', 'calibration_details', 'TEXT'),
            ('voices', 'model_profile', "TEXT DEFAULT 'base'"),
            ('sessions', 'voice_id', "TEXT DEFAULT 'browser-default'"),
        ]:
            _add_column(c, table, column, definition)
        # Older databases predate per-voice model routing.  Only the trained
        # Xilian records should retain the fine-tuned weights; every other
        # uploaded sample must use the v2ProPlus base model.
        c.execute(
            "UPDATE voices SET model_profile='xilian' WHERE model_profile='base' AND "
            "(id IN ('voice-f42877922900','voice-fac38ad29932') OR "
            "reference_path LIKE '%07c2ddaa9e9c48b38effbbe6713386f8%' OR "
            "reference_path LIKE '%5aef24da46e84719b2629ab0f7d04840%')"
        )
        presets = [
            ('browser-default', '系统默认', '自然', 'browser', '', '', 'zh'),
            ('steady', '沉稳主播', '沉稳', 'gpt-sovits', '', '', 'zh'),
            ('energetic', '活力主播', '活力', 'gpt-sovits', '', '', 'zh'),
            ('friendly', '亲民主播', '亲民', 'gpt-sovits', '', '', 'zh'),
        ]
        for row in presets:
            c.execute(
                'INSERT OR IGNORE INTO voices(id,name,style,provider,reference_path,prompt_text,prompt_lang,created_at) VALUES(?,?,?,?,?,?,?,?)',
                (*row, now()),
            )
        c.execute('''
          INSERT INTO document_versions(document_id,version,name,path,size,chunks,created_at)
          SELECT d.id,COALESCE(d.version,1),d.name,d.path,d.size,d.chunks,COALESCE(d.updated_at,d.created_at)
          FROM documents d
          WHERE NOT EXISTS (SELECT 1 FROM document_versions v WHERE v.document_id=d.id)
        ''')
